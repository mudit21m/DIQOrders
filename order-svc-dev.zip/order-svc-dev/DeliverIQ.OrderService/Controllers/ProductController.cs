﻿using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.Services.Interface;
using DeliverIQ.Services.Model.Request;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeliverIQ.OrderService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly ILogger<ProductController> _logger;
        private readonly IProductService _product;

        public ProductController(ILogger<ProductController> logger, IProductService product)
        {
            _logger = logger;
            _product = product;
        }

        /// <summary>
        /// Get Product List by login user
        /// </summary>
        /// <param name="user_id">login user id</param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetProducts")]
        public async Task<IActionResult> GetProducts([FromHeader(Name = "x-user")] long userId)
        {
            //var data = await _product.GetAllProducts(userId);
            var data = await _product.GetProductsByUserId(userId);
            return Ok(data);
        }

        [HttpGet]
        [Route("GetProductDetail")]
        public async Task<IActionResult> GetProductDetail([FromHeader(Name = "x-user")] long userId, [FromQuery] long productId)
        {
            var data = await _product.GetProductDetail(userId, productId);
            return Ok(data);
        }

        [HttpPost]
        public async Task<IActionResult> Add([FromBody] CreateEditProduct product)
        {
            var data = await _product.Add(product);
            return Ok(data);
        }

        [HttpGet]
        [Route("GetProductsFiscalGroups")]
        public async Task<IActionResult> GetProductsFiscalGroups([FromHeader(Name = "x-user")] long userId)
        {
            var data = await _product.GetProductsFiscalGroups(userId);
            return Ok(data);
        }
    }
}
