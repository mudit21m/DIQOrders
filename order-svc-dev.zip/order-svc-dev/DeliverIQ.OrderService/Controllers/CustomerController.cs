﻿using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.Services.Interface;
using DeliverIQ.Services.Model.Request;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeliverIQ.OrderService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly ILogger<CustomerController> _logger;
        private readonly IRecipientService _recipient;

        public CustomerController(ILogger<CustomerController> logger, IRecipientService recipient)
        {
            _logger = logger;
            _recipient = recipient;
        }

        [HttpGet]
        [Route("GetRecipients")]
        public async Task<IActionResult> GetRecipients([FromHeader(Name = "x-user")] long userId)
        {
            var data = await _recipient.GetAllRecipients(userId);
            return Ok(data);
        }

        [HttpGet]
        [Route("GetRecipientDetail")]
        public async Task<IActionResult> GetRecipientDetail([FromHeader(Name = "x-user")] long userId, [FromQuery] long recipientId)
        {
            var data = await _recipient.GetRecipientDetail(userId, recipientId);
            return Ok(data);
        }

        [HttpGet]
        [Route("GetRecipientDetailByEmail")]
        public async Task<IActionResult> GetRecipientDetailByEmail([FromHeader(Name = "x-user")] long userId, [FromQuery] string emailId)
        {
            var data = await _recipient.GetRecipientDetail(userId, emailId);
            return Ok(data);
        }
    }
}
