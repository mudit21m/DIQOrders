﻿using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.Services.Interface;
using DeliverIQ.Services.Model.Request;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeliverIQ.OrderService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UtilityController : ControllerBase
    {
        private readonly ILogger<UtilityController> _logger;
        private readonly IUtilityService _utility;

        public UtilityController(ILogger<UtilityController> logger, IUtilityService utility)
        {
            _logger = logger;
            _utility = utility;
        }

        [HttpGet]
        [Route("GetCountries")]
        public async Task<IActionResult> GetCountries()
        {
            var data = await _utility.GetAllCountries();
            return Ok(data);
        }

        [HttpGet]
        [Route("GetStates")]
        public async Task<IActionResult> GetStates([FromQuery] long countryId)
        {
            var data = await _utility.GetStatesByCountryId(countryId);
            return Ok(data);
        }

        [HttpGet]
        [Route("GetShippingMethods")]
        public async Task<IActionResult> GetShippingMethods()
        {
            var data = await _utility.GetShippingMethods();
            return Ok(data);
        }

        [HttpGet]
        [Route("GetShippingPrice")]
        public async Task<IActionResult> GetShippingPrice([FromQuery] long shippingMethodId)
        {
            var data =  _utility.GetShippingPrice(shippingMethodId);
            return Ok(data);
        }

        [HttpGet]
        [Route("GetPaymentTypes")]
        public async Task<IActionResult> GetPaymentTypes()
        {
            var data = await _utility.GetPaymentTypes();
            return Ok(data);
        }


        [HttpGet]
        [Route("GetTitles")]
        public async Task<IActionResult> GetTitles()
        {
            var data = await _utility.GetTitleMaster();
            return Ok(data);
        }

        [HttpGet]
        [Route("GetOrderStatus")]
        public async Task<IActionResult> GetOrderStatus()
        {
            var data = await _utility.GetOrderStatus();
            return Ok(data);
        }

        [HttpGet]
        [Route("GetMarketplaces")]
        public async Task<IActionResult> GetMarketplaces([FromHeader(Name = "x-user")] long? userId)
        {
            var data = await _utility.GetMarketplaces(userId);
            return Ok(data);
        }
    }
}
