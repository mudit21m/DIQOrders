﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.Services.Interface;
using DeliverIQ.Services.Model;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace DeliverIQ.OrderService.Controllers
{
    [EnableCors("CorsPolicy")]
    [ApiController]
    [Route("api/[controller]")]
    public class DocumentController : ControllerBase
    {
        private readonly ILogger<DocumentController> _logger;
        //private readonly IDocumentService _document;
        //private readonly IMenu _Menu;
        //private readonly ILink _Links;
        //private readonly IContent _PageContent;

        public DocumentController(ILogger<DocumentController> logger /*,IMenu Menu, ILink Links, IContent PageContent, IDocumentService document*/)
        {
            _logger = logger;
            //_Menu = Menu;
            //_Links = Links;
            //_PageContent = PageContent;
           // _document = document;
        }

        //private readonly IDocument _document;
        //public DocumentController(ILogger<DocumentController> logger, IDocument document)
        //{
        //    _logger = logger;
        //    _document = document;
        //}

        [HttpGet]
        public async Task<string> Get()
        {
           // await _document.GetAll();

            var task = await Task.Run(() =>
            {

                return "Welcome to Order";
            });
            return task;
        }
        //[HttpGet]
        //public async Task<IActionResult> GetAll()
        //{
        //    var data = await _document.GetAll();
        //    return Ok(data);
        //}
        //[HttpGet("{id}")]
        //public async Task<IActionResult> GetById(int id)
        //{
        //    var data = await _document.GetById(id);
        //    if (data == null) return Ok();
        //    return Ok(data);
        //}
        //[HttpPost]
        //public async Task<IActionResult> Add(Document document)
        //{
        //    var data = await _document.Add(document);
        //    return Ok(data);
        //}
        //[HttpDelete]
        //public async Task<IActionResult> Delete(int id)
        //{
        //    var data = await _document.Delete(id);
        //    return Ok(data);
        //}
        //[HttpPut]
        //public async Task<IActionResult> Update(Document document)
        //{
        //    var data = await _document.Update(document);
        //    return Ok(data);
        //}
        //#region Menu
        //[HttpGet]
        //[Route("GetAllMenu")]
        //public IActionResult GetAllMenu()
        //{
        //    return Ok(_Menu.GetAllAsync());
        //}
        //[HttpGet]
        //[Route("GetMenuById")]
        //public IActionResult GetMenuById(int Id)
        //{
        //    return Ok(_Menu.GetByIdAsync(Id));
        //}
        //[HttpPost]
        //[Route("InsertMenu")]
        //public IActionResult InsertMenu([FromBody] MenuRequest model)
        //{
        //    return Ok(_Menu.InsertAsync(model));
        //}
        //[HttpPut]
        //[Route("UpdateMenu")]
        //public IActionResult UpdateMenu([FromQuery] int Id, [FromBody] MenuRequest model)
        //{
        //    return Ok(_Menu.UpdateAsync(Id, model));
        //}
        //[HttpGet]
        //[Route("DeleteMenu")]
        //public IActionResult DeleteMenu([FromQuery] int id)
        //{
        //    return Ok(_Menu.DeleteAsync(id));
        //}
        //#endregion
        //#region Links
        //[HttpGet]
        //[Route("GetAllLinks")]
        //public IActionResult GetAllLinks([FromQuery] int MenuId)
        //{
        //    return Ok(_Links.GetAllAsync(MenuId));
        //}
        //[HttpGet]
        //[Route("GetLinksById")]
        //public IActionResult GetLinksById([FromQuery] int MenuId, [FromQuery] string Id)
        //{
        //    return Ok(_Links.GetByIdAsync(MenuId, Id));
        //}
        //[HttpPost]
        //[Route("InsertLinks")]
        //public IActionResult InsertLinks([FromQuery] int MenuId, [FromBody] LinkRequest model)
        //{
        //    return Ok(_Links.InsertAsync(MenuId, model));
        //}
        //[HttpPut]
        //[Route("UpdateLinks")]
        //public IActionResult UpdateLinks([FromQuery] int MenuId, [FromQuery] string Id, [FromBody] LinkRequest model)
        //{
        //    return Ok(_Links.UpdateAsync(MenuId, Id, model));
        //}
        //[HttpGet]
        //[Route("DeleteLinks")]
        //public IActionResult DeleteLinks([FromQuery] int MenuId, [FromQuery] string Id)
        //{
        //    return Ok(_Links.DeleteAsync(MenuId, Id));
        //}
        //#endregion
        //#region PageContent
        //[HttpGet]
        //[Route("GetContent")]
        //public IActionResult GetContent([FromQuery] int MenuId, [FromQuery] string LinkId)
        //{
        //    return Ok(_PageContent.GetByIdAsync(MenuId, LinkId));
        //}
        //[HttpGet]
        //[Route("UpdateContent")]
        //public IActionResult UpdateContent([FromQuery] int MenuId, [FromQuery] string LinkId, [FromBody] PageContentRequest model)
        //{
        //    return Ok(_PageContent.UpdateAsync(MenuId, LinkId, model));
        //}
        //[HttpPost]
        //[Route("DeleteContent")]
        //public IActionResult DeleteContent(int MenuId, string LinkId)
        //{
        //    return Ok(_PageContent.DeleteAsync(MenuId, LinkId));
        //}
        //#endregion
    }
}
