﻿using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.DataAccess.Data.Model.Request;
using DeliverIQ.Services.Interface;
using DeliverIQ.Services.Model.Request;
using DeliverIQ.Services.Model.Response;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace DeliverIQ.OrderService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly ILogger<OrderController> _logger;
        private readonly IOrderService _order;

        public OrderController(ILogger<OrderController> logger, IOrderService order)
        {
            _logger = logger;
            _order = order;
        }

        [HttpPost]
        [Route("GetOrders")]
        public async Task<IActionResult> GetOrders([FromHeader(Name = "x-user")] long userId, OrderFilter orderFilter)
        {
            var data = await _order.GetOrdersByUserId(userId, orderFilter);
            if (data == null)
                return StatusCode(Convert.ToInt32(HttpStatusCode.NoContent), "NoContent");
            else
                return Ok(data);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            CreateOrder data = await _order.GetOrderDetailsById(id);
            if (data == null)
                return StatusCode(Convert.ToInt32(HttpStatusCode.NoContent), "NoContent");
            else
                return Ok(data);
        }

        [HttpPost]
        public async Task<IActionResult> Add([FromHeader(Name = "x-user")] long userId, CreateOrder order)
        {
            if (userId > 0)
            {
                var data = await _order.AddOrder(order, userId);
                return Ok(data);
            }
            else
            {
              return  StatusCode(Convert.ToInt32(HttpStatusCode.BadRequest), "BadRequest");
            }
        }
        
        [HttpPut]
        public async Task<IActionResult> Update([FromHeader(Name = "x-user")] long userId, CreateOrder order)
        {
            var data = await _order.Update(order, userId);
            return Ok(data);
        }


    }
}
