﻿using Dapper;
using DeliverIQ.DataAccess.Data;
using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.Repositories.Interface;
using DeliverIQ.Utilities;
using Microsoft.Extensions.Configuration;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Repositories.Implementation
{
    public class StateRepository :  IStateRepository
    {
        private readonly IDbConnectionFactory _dbCnnectionFactory;
        public StateRepository(IDbConnectionFactory dbCnnectionFactory)
        {
            _dbCnnectionFactory = dbCnnectionFactory;
        }

        public Task<long> AddAsync(States entity)
        {
            throw new NotImplementedException();
        }

        public Task<int> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public Task<IReadOnlyList<States>> GetAllAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<IReadOnlyList<States>> GetStatesByCountryId(long countryId)
        {
            var sql = @"SELECT id,name,code,country_id FROM States where country_id = @countryId";
            using (IDbConnection connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryAsync<States>(sql, new { countryId = countryId });
                return result.ToList();
            }
        }

        public Task<States> GetByIdAsync(long id)
        {
            throw new NotImplementedException();
        }

        public Task<int> UpdateAsync(States entity)
        {
            throw new NotImplementedException();
        }
    }
}
