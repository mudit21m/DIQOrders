﻿using Dapper;
using DeliverIQ.DataAccess.Data;
using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.DataAccess.Data.Response;
using DeliverIQ.Repositories.Interface;
using DeliverIQ.Utilities;
using Microsoft.Extensions.Configuration;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Repositories.Implementation
{
    public class ProductRepository :  IProductRepository
    {
        private readonly IDbConnectionFactory _dbCnnectionFactory;
        public ProductRepository(IDbConnectionFactory dbCnnectionFactory)
        {
            _dbCnnectionFactory = dbCnnectionFactory;
        }
        public Task<long> AddAsync(Products entity)
        {
            throw new NotImplementedException();
        }

        public Task<int> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public Task<IReadOnlyList<Products>> GetAllAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<IReadOnlyList<ProductsFiscalGroups>> GetProductsFiscalGroups(long userId)
        {
            var sql = @"SELECT * FROM products_fiscal_groups where user_id = @userId;";
            using (IDbConnection connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryAsync<ProductsFiscalGroups>(sql, new { userId = userId });
                return result.ToList();
            }
        }

        public async Task<IReadOnlyList<Products>> GetAllProductsWithDetail(long userId)
        {
            var sql = @"SELECT * FROM products where user_id = @userId;";
            using (IDbConnection connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryAsync<Products>(sql, new { userId = userId });
                return result.ToList();
            }
        }

        public async Task<IReadOnlyList<ProductDetails>> GetAllProductsByUserId(long userId)
        {
            var sql = @"SELECT p.id,p.barcode,p.barcode_type_id,p.base_price,p.currency_id,p.diq_product_code,p.has_variant,p.product_description," +
                    "p.product_fiscal_group_id,p.product_name,p.product_status,p.user_id,product_tax," +
                    "pp.image_url,pp.variant_id as image_variant_id,pp.product_id as image_product_id, pp.id as variant_id, " +
                    "pv.additional_description as variant_additional_description, pv.barcode as variant_barcode, pv.barcode_type_id as variant_barcode_type_id, " +
                    "pv.is_seprate_barcode as variant_is_seprate_barcode,pv.product_id as variant_product_id, pv.variant_name, pv.id as variant_id, " +
                    "ppa.id as package_id,ppa.variant_id as package_variant_id,ppa.width as package_width, ppa.height as package_height, ppa.length as package_length, " +
                    "ppa.weight as package_weight, ppa.dim_unit as package_dim_unit, ppa.weight_unit as package_weight_unit " +
                    "FROM products p " +
                    "LEFT JOIN products_photos pp on P.id = PP.product_id " +
                    "LEFT JOIN products_variants pv on P.id = pv.product_id " +
                    "LEFT JOIN products_packages ppa on P.id = ppa.product_id " +
                    "where p.user_id = @userId;";

            using (IDbConnection connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryAsync<ProductDetails>(sql, new { userId = userId });
                return result.ToList();
            }
        }

        public async Task<IReadOnlyList<Products>> GetAllProducts(long userId)
        {
            var sql = @"SELECT * FROM products where user_id = @userId;";
            using (IDbConnection connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryAsync<Products>(sql, new { userId = userId });
                return result.ToList();
            }
        }

        public async Task<Products> GetProduct(long userId, long productId)
        {
            var sql = @"SELECT * FROM products where user_id = @userId and id = @productId;";
            using (IDbConnection connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryFirstOrDefaultAsync<Products>(sql, new { userId = userId, productId = productId });
                return result;
            }
        }

        public async Task<IReadOnlyList<ProductsPhotos>> GetProductPhotos(long productId)
        {
            var sql = @"SELECT * FROM products_photos where product_id = @productId;";
            using (IDbConnection connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryAsync<ProductsPhotos>(sql, new { productId = productId });
                return result.ToList();
            }
        }

        public async Task<IReadOnlyList<ProductsVariants>> GetProductVariants(long productId)
        {
            var sql = @"SELECT * FROM products_variants where product_id = @productId;";
            using (IDbConnection connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryAsync<ProductsVariants>(sql, new { productId = productId });
                return result.ToList();
            }
        }

        public Task<Products> GetByIdAsync(long id)
        {
            throw new NotImplementedException();
        }

        public Task<int> UpdateAsync(Products entity)
        {
            throw new NotImplementedException();
        }
    }
}
