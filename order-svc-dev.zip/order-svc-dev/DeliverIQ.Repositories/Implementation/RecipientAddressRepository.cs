﻿using Dapper;
using DeliverIQ.DataAccess.Data;
using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.Repositories.Interface;
using Microsoft.Extensions.Configuration;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Repositories.Implementation
{
    public class RecipientAddressRepository : IRecipientAddressRepository
    {
        private readonly IDbConnectionFactory _dbCnnectionFactory;
        public RecipientAddressRepository(IDbConnectionFactory dbCnnectionFactory)
        {
            _dbCnnectionFactory = dbCnnectionFactory;
        }
        

        public async Task<long> AddAsync(RecipientsAddresses entity)
        {
            var sql = "insert into recipients_addresses (recipient_id,address_type,delivery_address1,delivery_address2,delivery_address3,delivery_city," +
                "delivery_state_id,delivery_postal_code,delivery_country_id,delivery_is_residential,billing_address1,billing_address2,billing_address3," +
                "billing_city,billing_state_id,billing_postal_code,billing_country_id,billing_is_residential)values(@recipient_id,@address_type,@delivery_address1," +
                "@delivery_address2,@delivery_address3,@delivery_city,@delivery_state_id,@delivery_postal_code,@delivery_country_id,@delivery_is_residential," +
                "@billing_address1,@billing_address2,@billing_address3,@billing_city,@billing_state_id,@billing_postal_code,@billing_country_id," +
                "@billing_is_residential) RETURNING id";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.ExecuteScalarAsync(sql, entity);
                return Convert.ToInt64(result == null ? 0 : result);
            }
        }

        public Task<int> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public Task<IReadOnlyList<RecipientsAddresses>> GetAllAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<IReadOnlyList<RecipientsAddresses>> GetRecipientAddresses(long? recipientId)
        {
            var sql = @"SELECT * FROM recipients_addresses where recipient_id = @recipientId;";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryAsync<RecipientsAddresses>(sql, new { recipientId = recipientId});
                return result.ToList();
            }
        }

        public Task<RecipientsAddresses> GetByIdAsync(long id)
        {
            throw new NotImplementedException();
        }

        public async Task<long> UpdateByRecipientIdAsync(RecipientsAddresses entity)
        {
            var sql = "update recipients_addresses set address_type = @address_type,delivery_address1 = @delivery_address1," +
                "delivery_address2 = @delivery_address2,delivery_address3 = @delivery_address3,delivery_city = @delivery_city," +
                "delivery_state_id = @delivery_state_id,delivery_postal_code = @delivery_postal_code,delivery_country_id = @delivery_country_id," +
                "delivery_is_residential = @delivery_is_residential,billing_address1 = @billing_address1,billing_address2 = @billing_address2," +
                "billing_address3 = @billing_address3,billing_city = @billing_city,billing_state_id = @billing_state_id," +
                "billing_postal_code = @billing_postal_code,billing_country_id = @billing_country_id,billing_is_residential = @billing_is_residential " +
                "where recipient_id = @recipient_id RETURNING id";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.ExecuteScalarAsync(sql, entity);
                return Convert.ToInt64(result == null ? 0 : result);
            }
        }

        public Task<int> UpdateAsync(RecipientsAddresses entity)
        {
            throw new NotImplementedException();
        }
    }
}
