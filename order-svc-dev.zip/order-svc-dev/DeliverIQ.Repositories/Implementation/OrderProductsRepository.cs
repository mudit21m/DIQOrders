﻿using Dapper;
using DeliverIQ.DataAccess.Data;
using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.Repositories.Interface;
using DeliverIQ.Utilities;
using Microsoft.Extensions.Configuration;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Repositories.Implementation
{
    public class OrderProductsRepository :  IOrderProductsRepository
    {
        private readonly IDbConnectionFactory _dbCnnectionFactory;
        public OrderProductsRepository(IDbConnectionFactory dbCnnectionFactory)
        {
            _dbCnnectionFactory = dbCnnectionFactory;
        }
        public async Task<long> AddAsync(OrdersProducts entity)
        {
            var sql = "insert into orders_products (order_id,product_id,variant_name,product_name,varient_id,unit_price,quantity," +
                "is_active,shipment_id,created_on,created_by)" +
                "values(@order_id,@product_id,@variant_name,@product_name,@varient_id,@unit_price,@quantity,@is_active,@shipment_id," +
                "@created_on,@created_by) RETURNING id";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.ExecuteAsync(sql, entity);
                return result;
            }
        }
        public Task<int> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public Task<int> UpdateAsync(OrdersProducts entity)
        {
            throw new NotImplementedException();
        }

        //public async Task<int> DeleteAsync(int id)
        //{
        //    var sql = "DELETE FROM Products WHERE Id = @Id";
        //    using (var connection = Connection)
        //    {
        //        connection.Open();
        //        var result = await connection.ExecuteAsync(sql, new { Id = id });
        //        return result;
        //    }
        //}
        public async Task<IReadOnlyList<OrdersProducts>> GetAllAsync()
        {
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryAsync<OrdersProducts>("GetAllOrders",
                        //  new { Model = model },
                        commandType: CommandType.StoredProcedure);

                return result.ToList();
            }
        }
      
        public async Task<OrdersProducts> GetByIdAsync(long id)
        {
            var sql = "SELECT * FROM Orders WHERE Id = @Id";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QuerySingleOrDefaultAsync<OrdersProducts>(sql, new { Id = id });
                return result;
            }
        }
        //public async Task<int> UpdateAsync(Document entity)
        //{
        //    //  entity.ModifiedOn = DateTime.Now;
        //    var sql = "UPDATE Products SET Name = @Name, Description = @Description, Barcode = @Barcode, Rate = @Rate, ModifiedOn = @ModifiedOn  WHERE Id = @Id";
        //    using (var connection = Connection)
        //    {
        //        connection.Open();
        //        var result = await connection.ExecuteAsync(sql, entity);
        //        return result;
        //    }
        //}
    }
}
