﻿using Dapper;
using DeliverIQ.DataAccess.Data;
using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.Repositories.Interface;
using Microsoft.Extensions.Configuration;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Repositories.Implementation
{
    public class OrderAddressRepository : IOrderAddressRepository
    {
        private readonly IDbConnectionFactory _dbCnnectionFactory;
        public OrderAddressRepository(IDbConnectionFactory dbCnnectionFactory)
        {
            _dbCnnectionFactory = dbCnnectionFactory;
        }
        public async Task<long> AddAsync(OrdersAddresses entity)
        {
            var sql = "insert into orders_addresses(title,email_id,surname,order_address_type, name, company, address_line_1, " +
                "address_line_2, address_line_3, city, state_id,postal_code, phone_no, country_id,order_id) " +
                "values (@title,@email_id,@surname,@order_address_type, @name, @company, @address_line_1, " +
                "@address_line_2, @address_line_3, @city, @state_id,@postal_code, @phone_no, @country_id,@order_id,@created_on,@created_by)  " +
                "SELECT CAST(SCOPE_IDENTITY()  as int) as id";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.ExecuteScalarAsync(sql, entity);
                return Convert.ToInt64(result);
            }
        }

        public async Task<int> DeleteAsync(int id)
        {
            var sql = "DELETE FROM Orders_Addresses WHERE Id = @Id";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.ExecuteAsync(sql, new { Id = id });
                return result;
            }
        }

        public async Task<IReadOnlyList<OrdersAddresses>> GetAllAsync()
        {
            var sql = @"SELECT firstname FROM Orders_Addresses;";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryAsync<OrdersAddresses>(sql);
                return result.ToList();
            }
        }

        public async Task<IReadOnlyList<OrdersAddresses>> GetReturningCustomer(int orderid)
        {
            var sql = @"SELECT firstname FROM Orders_Addresses  WHERE order_id = @orderid;";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryAsync<OrdersAddresses>(sql);
                return result.ToList();
            }
        }

        public async Task<OrdersAddresses> GetByIdAsync(long id)
        {
            var sql = "SELECT * FROM OrdersAddresses WHERE Id = @Id";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QuerySingleOrDefaultAsync<OrdersAddresses>(sql, new { Id = id });
                return result;
            }
        }
        public async Task<int> UpdateAsync(OrdersAddresses entity)
        {
            //  entity.ModifiedOn = DateTime.Now;
            var sql = "update orders_addresses set order_address_type = @order_address_type, name = @name, company = @company," +
                "address_line_1 = @address_line_1,address_line_2 = @address_line_2,address_line_3 = @address_line_3,city = @city," +
                "state_id = @state_id,postal_code = @postal_code,phone_no = @phone_no,country_id = @country_id,updated_on = @updated_on," +
                "updated_by = @updated_by,title = @title,surname = @surname,is_residential = @is_residential,email_id = @email_id " +
                "where id = @id and order_id = @order_id";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.ExecuteAsync(sql, entity);
                return result;
            }
        }
    }
}
