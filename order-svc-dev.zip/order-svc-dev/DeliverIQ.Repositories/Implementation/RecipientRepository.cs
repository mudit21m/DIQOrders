﻿using Dapper;
using DeliverIQ.DataAccess.Data;
using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.DataAccess.Data.Response;
using DeliverIQ.Repositories.Interface;
using DeliverIQ.Utilities;
using Microsoft.Extensions.Configuration;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Repositories.Implementation
{
    public class RecipientRepository : IRecipientRepository
    {
        private readonly IDbConnectionFactory _dbCnnectionFactory;
        public RecipientRepository(IDbConnectionFactory dbCnnectionFactory)
        {
            _dbCnnectionFactory = dbCnnectionFactory;
        }
        public async Task<long> AddAsync(Recipients entity)
        {
            var sql = "insert into recipients(user_id,name,surname,title,email_id,phone_number,created_on,updated_on,created_by,updated_by,is_active,is_deleted) " +
                "values (@user_id,@name,@surname,@title,@email_id,@phone_number,@created_on,@updated_on,@created_by,@updated_by,@is_active,@is_deleted)  " +
                "RETURNING id";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.ExecuteScalarAsync(sql, entity);
                return Convert.ToInt64(result == null ? 0 : result);
            }
        }

        public Task<int> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public Task<IReadOnlyList<Recipients>> GetAllAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<IReadOnlyList<RecipientDetails>> GetAllRecipients(long userId)
        {
            var sql = @"SELECT  " +
                        "r.id, r.title,r.name,r.surname,r.phone_number,r.email_id," +
                        "ra.id as address_id,recipient_id,address_type,delivery_address1,delivery_address2,delivery_address3,delivery_city,delivery_state_id,delivery_postal_code," +
                        "delivery_country_id,delivery_is_residential,billing_address1,billing_address2,billing_address3,billing_city,billing_state_id,billing_postal_code," +
                        "billing_country_id,billing_is_residential " +

                        "FROM recipients r " +
                        "left join recipients_addresses ra on r.id = ra.recipient_id " +
                    "where user_id = @userId;";
            using (IDbConnection connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryAsync<RecipientDetails>(sql, new { userId = userId });
                return result.ToList();
            }
        }

        public async Task<Recipients> GetRecipient(long userId, long recipientId)
        {
            var sql = @"SELECT id,user_id,name,surname,title,email_id,phone_number,is_active,is_deleted,created_by,updated_by,created_on,updated_on FROM recipients where user_id = @userId and id = @recipientId;";
            using (IDbConnection connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryFirstOrDefaultAsync<Recipients>(sql, new { userId = userId, recipientId = recipientId });
                return result;
            }
        }

        public async Task<Recipients> GetRecipient(long userId, string emailId)
        {
            var sql = @"SELECT * FROM recipients where user_id = @userId and email_id = @emailId;";
            using (IDbConnection connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryFirstOrDefaultAsync<Recipients>(sql, new { userId = userId, emailId = emailId });
                return result;
            }
        }

        public Task<Recipients> GetByIdAsync(long id)
        {
            throw new NotImplementedException();
        }

        public async Task<long> UpdateByEmailAsync(Recipients entity)
        {
            var sql = "update recipients set name = @name,surname = @surname,title = @title,phone_number = @phone_number,updated_on = @updated_on,updated_by = @updated_by," +
                 "is_active = true where email_id = @email_id and user_id = @user_id RETURNING id;";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.ExecuteScalarAsync(sql, entity);
                return Convert.ToInt64(result == null ? 0 : result);
            }
        }

        public async Task<int> CheckRecipientExist(long user_id, string email_id)
        {
            var sql = "select count(c.id) from recipients c where c.email_id =@email_id and c.user_id =@user_id";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.ExecuteScalarAsync(sql, new { user_id = user_id, email_id = email_id });
                return Convert.ToInt32(result == null ? 0 : result);
            }
        }

        public Task<int> UpdateAsync(Recipients entity)
        {
            throw new NotImplementedException();
        }
    }
}
