﻿using Dapper;
using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.Repositories.Interface;
using DeliverIQ.Utilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DeliverIQ.Repositories.Implementation
{
    public class MarketplaceRepository : IMarketplaceRepository
    {
        private readonly IDbConnectionFactory _dbCnnectionFactory;
        public MarketplaceRepository(IDbConnectionFactory dbCnnectionFactory)
        {
            _dbCnnectionFactory = dbCnnectionFactory;
        }

        public Task<long> AddAsync(Marketplaces entity)
        {
            throw new NotImplementedException();
        }

        public Task<int> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<IReadOnlyList<Marketplaces>> GetAllAsync()
        {
            var sql = @"SELECT m.id, m.name FROM marketplaces m";
            using (IDbConnection connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryAsync<Marketplaces>(sql);
                return result.ToList();
            }
        }

        public async Task<IReadOnlyList<Marketplaces>> GetMarketplacesByUserId(long? userId)
        {
            var sql = "";

            if (userId != null)
            {
                sql = @"SELECT m.id, m.name FROM marketplaces m inner join users_marketplaces um " +
                        " on m.id = um.marketplace_id where user_id = @userId";
            }
            else
            {
                sql = @"SELECT m.id, m.name FROM marketplaces m";
            }

            using (IDbConnection connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryAsync<Marketplaces>(sql, new { userId = userId });
                return result.ToList();
            }
        }

        public Task<Marketplaces> GetByIdAsync(long id)
        {
            throw new NotImplementedException();
        }

        public Task<int> UpdateAsync(Marketplaces entity)
        {
            throw new NotImplementedException();
        }
    }
}
