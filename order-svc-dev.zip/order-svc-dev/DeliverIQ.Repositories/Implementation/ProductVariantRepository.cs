﻿using Dapper;
using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.Repositories.Interface;
using DeliverIQ.Utilities;
using Microsoft.Extensions.Configuration;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Repositories.Implementation
{
    public class ProductVariantRepository :  IProductVariantRepository
    {
        private readonly IDbConnectionFactory _dbCnnectionFactory;
        public ProductVariantRepository(IDbConnectionFactory dbCnnectionFactory)
        {
            _dbCnnectionFactory = dbCnnectionFactory;
        }
        public Task<long> AddAsync(ProductsVariants entity)
        {
            throw new NotImplementedException();
        }

        public Task<int> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public Task<IReadOnlyList<ProductsVariants>> GetAllAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<ProductsVariants> GetByIdAsync(long id)
        {
            var sql = @"select * from products_variants pv where pv.id = @id;";
            using (IDbConnection connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryFirstOrDefaultAsync<ProductsVariants>(sql, new { id = id});
                return result;
            }
        }

        public Task<int> UpdateAsync(ProductsVariants entity)
        {
            throw new NotImplementedException();
        }
    }
}
