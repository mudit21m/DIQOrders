﻿using Dapper;
using DeliverIQ.DataAccess.Data;
using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.Repositories.Interface;
using DeliverIQ.Utilities;
using Microsoft.Extensions.Configuration;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Repositories.Implementation
{
    public class CountryRepository : ICountryRepository
    {
        private readonly IDbConnectionFactory _dbCnnectionFactory;
        public CountryRepository(IDbConnectionFactory dbCnnectionFactory)
        {
            _dbCnnectionFactory = dbCnnectionFactory;
        }
        public Task<long> AddAsync(Countries entity)
        {
            throw new NotImplementedException();
        }

        public Task<int> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public Task<IReadOnlyList<Countries>> GetAllAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<IReadOnlyList<Countries>> GetAllCountries()
        {
            var sql = @"SELECT name,code,culture_code,continent,postalcode,location,statecode,timezone,id FROM Countries";
            using (IDbConnection connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryAsync<Countries>(sql);
                return result.ToList();
            }
        }

        public Task<Countries> GetByIdAsync(long id)
        {
            throw new NotImplementedException();
        }

        public Task<int> UpdateAsync(Countries entity)
        {
            throw new NotImplementedException();
        }
    }
}
