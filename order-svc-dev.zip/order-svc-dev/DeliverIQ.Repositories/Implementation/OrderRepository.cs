﻿using Dapper;
using DeliverIQ.DataAccess.Data;
using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.DataAccess.Data.Model.Request;
using DeliverIQ.DataAccess.Data.Model.Response;
using DeliverIQ.Repositories.Interface;
using DeliverIQ.Utilities;
using Microsoft.Extensions.Configuration;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace DeliverIQ.Repositories.Implementation
{
    public class OrderRepository : IOrderRepository
    {
        private readonly IDbConnectionFactory _dbCnnectionFactory;
        public OrderRepository(IDbConnectionFactory dbCnnectionFactory)
        {
            _dbCnnectionFactory = dbCnnectionFactory;
        }
        public async Task<long> AddAsync(Orders entity)
        {
            var sql = "insert into Orders(customer_marketplace_id, diq_order_number, marketplace_order_number, marketplace_order_id, " +
                "order_date, order_created_date, order_modified_date, ship_by_date,order_status_id, order_total, shipping_amount, " +
                "is_fulfilled, order_modification_status, shipping_type_mode, ship_transit_time, order_subtotal, order_discount," +
                "order_discount_type, order_misc_charges, order_tax, order_carrier, order_shipping_notes, payment_type, created_on, " +
                "created_by, user_id) " +
                "values (@customer_marketplace_id,@diq_order_number,@marketplace_order_number,@marketplace_order_id,@order_date," +
                "@order_created_date,@order_modified_date,@ship_by_date,@order_status_id,@order_total,@shipping_amount,@is_fulfilled," +
                "@order_modification_status,@shipping_type_mode,@ship_transit_time,@order_subtotal,@order_discount,@order_discount_type," +
                "@order_misc_charges,@order_tax,@order_carrier,@order_shipping_notes,@payment_type,@created_on,@created_by,@user_id)  " +
                "SELECT CAST(SCOPE_IDENTITY()  as int) as id";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.ExecuteScalarAsync(sql, entity);
                return Convert.ToInt64(result == null ? 0 : result);
            }
        }

        public Task<int> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<int> UpdateAsync(Orders entity)
        {
            var sql = "update Orders set order_carrier = @order_carrier,order_date = @order_date,order_discount = @order_discount,order_discount_type = @order_discount_type," +
                    "order_misc_charges = @order_misc_charges,order_modified_date = @order_modified_date,order_shipping_notes = @order_shipping_notes," +
                    "order_subtotal = @order_subtotal,order_tax = @order_tax,order_total = @order_total,payment_type = @payment_type," +
                    "ship_by_date = @ship_by_date,ship_transit_time = @ship_transit_time,shipping_amount = @shipping_amount,shipping_type_mode = @shipping_type_mode," +
                    "updated_by = @updated_by,updated_on = @updated_on where id = @order_id";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.ExecuteAsync(sql, entity);
                return result;
            }
        }

        public async Task<Orders> GetByIdAsync(long id)
        {
            var sql = "SELECT * FROM Orders WHERE Id = @Id";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QuerySingleOrDefaultAsync<Orders>(sql, new { Id = id });
                return result;
            }
        }

        public async Task<long> UpdateOrderActiveFlag(long id, bool isActive)
        {
            //  entity.ModifiedOn = DateTime.Now;
            var sql = "UPDATE order SET is_active= isActive WHERE Id = @Id RETURNING id;";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.ExecuteScalarAsync(sql, new { id = id, is_active = isActive });
                return Convert.ToInt64(result == null ? 0 : result);
            }
        }

        public async Task<List<OrderList>> GetOrdersByUserId(long userId, OrderFilter filters)
        {
            StringBuilder sql = new StringBuilder();

            sql.Append("select " +
                        "o.id ,o.diq_order_number,o.order_created_date ,o.order_status_id,o.marketplace_order_number, o.order_total ," +
                        "del.country_id as del_country_id, del.postal_code as del_postal_code,del.name , del.surname,del.postal_code as del_postal_code , c.name as del_country_name, " +
                        "del.city as del_city, del.state_id as del_state_id,del.email_Id, del.phone_no, s.carrier_tracking_no " +
                        "um.marketplace_id, m.name ::text || um.store_name as marketplace_name " +

                        " from orders o " +
                        " left join orders_addresses del on del.order_id = o.id and del.order_address_type = 2 " +//delivery
                        " left join users_marketplaces um on um.user_id = o.user_id " +
                        " left join countries c on c.id = del.country_id " +
                        " left join users u on u.id = o.user_id " +
                        " left join shipments s on s.user_id = u.user_id " +
                        " left join marketplaces m on m.id = um.marketplace_id");


            sql.Append(" where o.user_id = @userId and o.is_active = true ");

            StringBuilder columnFilter = new StringBuilder();

            #region "Column Filters"
            if (filters.Amount != null && filters.Amount.Filter.Count > 0 && decimal.TryParse(filters.Amount.Filter[0], out decimal value))
            {
                columnFilter.Append(" and o.order_total = " + value);
            }

            if (filters.Channel != null && filters.Channel.Filter.Count > 0 && !string.IsNullOrWhiteSpace(filters.Channel.Filter[0]))
            {
                columnFilter.Append(" and (");

                for (int i = 0; i < filters.Channel.Filter.Count; i++)
                {
                    columnFilter.Append(" um.marketplace_id = " + filters.Channel.Filter[i] + (i < filters.Channel.Filter.Count - 1 ? " or " : string.Empty));
                }

                columnFilter.Append(")");
            }

            if (filters.Customer != null && filters.Customer.Filter.Count > 0 && !string.IsNullOrWhiteSpace(filters.Customer.Filter[0]))
            {
                string[] name = filters.Customer.Filter[0].Split(' ');

                columnFilter.Append(" and (");

                for (int i = 0; i < name.Length; i++)
                {
                    columnFilter.Append(" del.name like '" + name[i] + "%' or del.surname like '" + name[i] + "%'  " + (i < filters.Customer.Filter.Count - 1 ? " or " : string.Empty));
                }

                columnFilter.Append(")");
            }

            if (filters.CreatedDate != null && filters.CreatedDate.Filter.Count > 0 && !string.IsNullOrWhiteSpace(filters.CreatedDate.Filter[0]))
            {
                columnFilter.Append(" and (");

                if (filters.CreatedDate.Filter.Count == 1)
                {
                    columnFilter.Append(" o.order_created_date >= '" + filters.CreatedDate.Filter[0] + "'");
                }
                else if (filters.CreatedDate.Filter.Count > 1)
                {
                    if (!string.IsNullOrWhiteSpace(filters.CreatedDate.Filter[0]) && !string.IsNullOrWhiteSpace(filters.CreatedDate.Filter[1]))
                    {
                        columnFilter.Append(" o.order_created_date >= '" + filters.CreatedDate.Filter[0] + "' and o.order_created_date <= '" + filters.CreatedDate.Filter[1] + "'");
                    }
                    else if (string.IsNullOrWhiteSpace(filters.CreatedDate.Filter[0]) && !string.IsNullOrWhiteSpace(filters.CreatedDate.Filter[1]))
                    {
                        columnFilter.Append(" o.order_created_date <= '" + filters.CreatedDate.Filter[1] + "'");
                    }
                }

                columnFilter.Append(")");
            }

            if (filters.Status != null && filters.Status.Filter.Count > 0 && !string.IsNullOrWhiteSpace(filters.Status.Filter[0]))
            {
                columnFilter.Append(" and (");

                for (int i = 0; i < filters.Status.Filter.Count; i++)
                {
                    columnFilter.Append(" o.order_status_id = " + filters.Status.Filter[i] + (i < filters.Status.Filter.Count - 1 ? " or " : string.Empty));
                }

                columnFilter.Append(")");
            }

            if (filters.Order != null && filters.Order.Filter.Count > 0 && !string.IsNullOrWhiteSpace(filters.Order.Filter[0]))
            {
                columnFilter.Append(" and o.diq_order_number like '" + filters.Order.Filter[0] + "%'");
            }

            if (filters.Postcode != null && filters.Postcode.Filter.Count > 0 && !string.IsNullOrWhiteSpace(filters.Postcode.Filter[0]))
            {
                columnFilter.Append(" and del.postal_code like '" + filters.Postcode.Filter[0] + "%'");
            }

            if (filters.Country != null && filters.Country.Filter.Count > 0 && !string.IsNullOrWhiteSpace(filters.Country.Filter[0]))
            {
                columnFilter.Append(" and del.country_id = " + filters.Country.Filter[0]);
            }

            if (filters.SourceId != null && filters.SourceId.Filter.Count > 0 && !string.IsNullOrWhiteSpace(filters.SourceId.Filter[0]))
            {
                columnFilter.Append(" and o.marketplace_order_number like '" + filters.SourceId.Filter[0] + "%'");
            }

            #endregion

            StringBuilder advanceFilter = new StringBuilder();

            #region "Advance Filters"
            if (filters.AdvanceFilter != null && filters.AdvanceFilter.IsAdavanceFilterApply)
            {
                if (filters.AdvanceFilter.CarrierTrackingReference != null && !string.IsNullOrWhiteSpace(filters.AdvanceFilter.CarrierTrackingReference.Filter))
                {
                    advanceFilter.Append(" and s.carrier_tracking_no like '" + filters.AdvanceFilter.CarrierTrackingReference.Filter + "%'");
                }

                if (filters.AdvanceFilter.CustomerReference != null && !string.IsNullOrWhiteSpace(filters.AdvanceFilter.CustomerReference.Filter))
                {
                    advanceFilter.Append(" and u.diq_reference_number like '" + filters.AdvanceFilter.CustomerReference.Filter + "%'");
                }

                if (filters.AdvanceFilter.DeliveryIQOrderNumber != null && !string.IsNullOrWhiteSpace(filters.AdvanceFilter.DeliveryIQOrderNumber.Filter))
                {
                    advanceFilter.Append(" and o.diq_order_number like '" + filters.AdvanceFilter.DeliveryIQOrderNumber.Filter + "%'");
                }

                if (filters.AdvanceFilter.DeliveryPostcode != null && !string.IsNullOrWhiteSpace(filters.AdvanceFilter.DeliveryPostcode.Filter))
                {
                    advanceFilter.Append(" and del.postal_code like '" + filters.AdvanceFilter.DeliveryPostcode.Filter + "%'");
                }
                if (filters.AdvanceFilter.EmailAddress != null && !string.IsNullOrWhiteSpace(filters.AdvanceFilter.EmailAddress.Filter))
                {
                    advanceFilter.Append(" and del.email_id like '" + filters.AdvanceFilter.EmailAddress.Filter + "%'");
                }

                if (filters.AdvanceFilter.ProductDescription != null && !string.IsNullOrWhiteSpace(filters.AdvanceFilter.ProductDescription.Filter))
                {
                    advanceFilter.Append(" and p.product_description like '%" + filters.AdvanceFilter.ProductDescription.Filter + "%'");
                }

                if (filters.AdvanceFilter.Source != null && !string.IsNullOrWhiteSpace(filters.AdvanceFilter.Source.Filter))
                {
                    advanceFilter.Append(" and o.customer_marketplace_id = '" + filters.AdvanceFilter.Source.Filter + "'");
                }

                if (filters.AdvanceFilter.SourceOrderNumber != null && !string.IsNullOrWhiteSpace(filters.AdvanceFilter.SourceOrderNumber.Filter))
                {
                    advanceFilter.Append(" and o.marketplace_order_number = '" + filters.AdvanceFilter.SourceOrderNumber.Filter + "'");
                }

                if (filters.AdvanceFilter.Surname != null && !string.IsNullOrWhiteSpace(filters.AdvanceFilter.Surname.Filter))
                {
                    advanceFilter.Append(" and del.surname = '" + filters.AdvanceFilter.Surname.Filter + "%'");
                }

                if (filters.AdvanceFilter.TelephoneNumber != null && !string.IsNullOrWhiteSpace(filters.AdvanceFilter.TelephoneNumber.Filter))
                {
                    advanceFilter.Append(" and del.phone_no = '" + filters.AdvanceFilter.TelephoneNumber.Filter + "%'");
                }
            }

            if (string.IsNullOrWhiteSpace(advanceFilter.ToString()))
            {
                sql.Append(columnFilter);
            }
            else if (string.IsNullOrWhiteSpace(columnFilter.ToString()))
            {
                sql.Append(advanceFilter);
            }
            else
            {
                sql.Append(" and ((" + columnFilter.ToString().Substring(5, columnFilter.ToString().Length - 5));
                sql.Append(" ) or ( ");
                sql.Append(advanceFilter.ToString().Substring(5, advanceFilter.ToString().Length - 5) + "))");
            }

            #endregion

            #region "Sorting"
            sql.Append(" order by ");

            if (filters.Amount != null && !string.IsNullOrWhiteSpace(filters.Amount.Sort))
            {
                sql.Append(" o.order_total " + filters.Amount.Sort);
            }
            else if (filters.Channel != null && !string.IsNullOrWhiteSpace(filters.Channel.Sort))
            {
                sql.Append(" m.name " + filters.Channel.Sort + " , um.store_name " + filters.Channel.Sort);
            }
            else if (filters.CreatedDate != null && !string.IsNullOrWhiteSpace(filters.CreatedDate.Sort))
            {
                sql.Append(" o.order_created_date " + filters.CreatedDate.Sort);
            }
            else if (filters.Customer != null && !string.IsNullOrWhiteSpace(filters.Customer.Sort))
            {
                sql.Append(" del.name " + filters.Customer.Sort + " , del.surname " + filters.Customer.Sort);
            }
            else if (filters.Order != null && !string.IsNullOrWhiteSpace(filters.Order.Sort))
            {
                sql.Append(" o.diq_order_number " + filters.Order.Sort);
            }
            else if (filters.SourceId != null && !string.IsNullOrWhiteSpace(filters.SourceId.Sort))
            {
                sql.Append(" o.marketplace_order_number " + filters.SourceId.Sort);
            }
            else if (filters.Status != null && !string.IsNullOrWhiteSpace(filters.Status.Sort))
            {
                sql.Append(" o.order_status_id " + filters.Status.Sort); // TODO
            }
            else if (filters.Postcode != null && filters.Country != null && !string.IsNullOrWhiteSpace(filters.Postcode.Sort) && !string.IsNullOrWhiteSpace(filters.Country.Sort))
            {
                sql.Append(" del.postal_code " + filters.Postcode.Sort + ", del.country_id " + filters.Country.Sort);
            }
            else if (filters.Postcode != null && !string.IsNullOrWhiteSpace(filters.Postcode.Sort))
            {
                sql.Append(" del.postal_code " + filters.Postcode.Sort);
            }
            else if (filters.Country != null && !string.IsNullOrWhiteSpace(filters.Country.Sort))
            {
                sql.Append(" del.country_id " + filters.Country.Sort);
            }
            else
            {
                sql.Append(" o.diq_order_number desc ");
            }
            #endregion

            #region "Pagging"

            int skipRecords = 0;
            int nextRecords = 10;

            if (filters.Pagging != null)
            {
                skipRecords = (filters.Pagging.PageNo - 1) * filters.Pagging.PageSize;
                nextRecords = filters.Pagging.PageSize;
            }

            sql.Append(" OFFSET " + skipRecords + " ROWS FETCH NEXT " + nextRecords + " ROWS ONLY");

            #endregion


            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryAsync<OrderList>(sql.ToString(), new { userId = userId });
                return result.ToList();
            }
        }

        public async Task<List<OrderDetails>> GetOrderDetailsById(long orderId)
        {
            var sql = "select " +
                        //order table
                        "o.id ,o.diq_order_number ,o.order_date ,o.order_created_date,o.ship_by_date ,o.order_status_id ,o.order_total ,o.shipping_amount," +
                        "o.is_fulfilled,o.order_modification_status,o.shipping_type_mode,o.ship_transit_time,o.order_subtotal,o.order_discount,o.order_discount_type," +
                        "o.order_tax,o.order_shipping_notes,o.payment_type,o.user_id," +

                        //order_address billing
                        "bill.order_address_type as bill_order_address_type,bill.country_id as bill_country_id,bill.address_line_1 as bill_address_line_1," +
                        "bill.address_line_2 as bill_address_line_2,bill.address_line_3 as bill_address_line_3,bill.city as bill_city,bill.postal_code as bill_postal_code," +
                        "bill.is_residential as bill_is_residential,bill.state_id as bill_state_id,bill.id as bill_id,bill.title,bill.name,bill.surname," +
                        "bill.phone_no,bill.email_id," +

                        //order_address delivery
                        "del.order_address_type as del_order_address_type,del.country_id as del_country_id,del.address_line_1 as del_address_line_1," +
                        "del.address_line_2 as del_address_line_2,del.address_line_3 as del_address_line_3,del.city as del_city,del.postal_code as del_postal_code," +
                        "del.is_residential as del_is_residential,del.state_id as del_state_id,del.id as del_id," +
                        //Product
                        "op.id as order_product_id,op.varient_id ,op.product_id ,op.quantity ,op.variant_name ,op.product_name ,op.unit_price, op.shipment_id" +
                        " from orders o " +
                        "left join orders_addresses bill on bill.order_id = o.id and bill.order_address_type = 1 " +//billing
                        "left join orders_addresses del on del.order_id = o.id and del.order_address_type = 2 " +//delivery
                        "left join orders_products op on op.order_id = o.id " +
                        "where o.id = @id and o.is_active = 1";
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                var result = await connection.QueryAsync<OrderDetails>(sql, new { id = orderId });
                return result.ToList();
            }

        }

        public Task<IReadOnlyList<Orders>> GetAllAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<long> AddOrderDetailDataAsync(Orders orders, OrdersAddresses billingAddress, OrdersAddresses deliveryAddress, List<OrdersProducts> lstProducts, Recipients recipients, RecipientsAddresses recipientsAddresses)
        {
            long orderId = 0;
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                using (var tran = connection.BeginTransaction())
                {
                    try
                    {
                        var oredr_sql = "insert into Orders(customer_marketplace_id, diq_order_number, marketplace_order_number, marketplace_order_id, " +
                       "order_date, order_created_date, order_modified_date, ship_by_date,order_status_id, order_total, shipping_amount, " +
                       "is_fulfilled, order_modification_status, shipping_type_mode, ship_transit_time, order_subtotal, order_discount," +
                       "order_discount_type, order_misc_charges, order_tax, order_carrier, order_shipping_notes, payment_type, created_on, " +
                       "created_by, user_id) " +
                       "values (@customer_marketplace_id,@diq_order_number,@marketplace_order_number,@marketplace_order_id,@order_date," +
                       "@order_created_date,@order_modified_date,@ship_by_date,@order_status_id,@order_total,@shipping_amount,@is_fulfilled," +
                       "@order_modification_status,@shipping_type_mode,@ship_transit_time,@order_subtotal,@order_discount,@order_discount_type," +
                       "@order_misc_charges,@order_tax,@order_carrier,@order_shipping_notes,@payment_type,@created_on,@created_by,@user_id)  " +
                       "SELECT CAST(SCOPE_IDENTITY()  as int) as id";
                        var result = await connection.ExecuteScalarAsync(oredr_sql, orders, tran);
                        orderId = Convert.ToInt64(result == null ? 0 : result);

                        deliveryAddress.order_id = orderId;
                        deliveryAddress.order_address_type = Utilities.AddressType.Delivery;
                       
                        var Address_sql = "insert into orders_addresses(is_residential,title,email_id,surname,order_address_type, name, company, address_line_1, " +
                       "address_line_2, address_line_3, city, state_id,postal_code, phone_no, country_id,order_id) " +
                       "values (@is_residential,@title,@email_id,@surname,@order_address_type, @name, @company, @address_line_1, " +
                       "@address_line_2, @address_line_3, @city, @state_id,@postal_code, @phone_no, @country_id,@order_id)  ";


                        await connection.ExecuteAsync(Address_sql, deliveryAddress, tran);

                        billingAddress.order_id = orderId;
                        billingAddress.order_address_type = Utilities.AddressType.Billing;
                        await connection.ExecuteAsync(Address_sql, billingAddress, tran);

                        var product_sql = "insert into orders_products (is_deleted,order_id,product_id,variant_name,product_name,varient_id,unit_price,quantity," +
                           "is_active,shipment_id,created_on,created_by)" +
                           "values(@is_deleted,@order_id,@product_id,@variant_name,@product_name,@varient_id,@unit_price,@quantity,@is_active,@shipment_id," +
                           "@created_on,@created_by)";
                        foreach (OrdersProducts data in lstProducts)
                        {
                            data.order_id = orderId;
                            await connection.ExecuteAsync(product_sql, data, tran);
                        }

                        var recipient_sql = "select count(c.id) from recipients c where c.email_id =@email_id and c.user_id =@user_id";
                        var recipient_address_sql = "";
                        long recipient_id = 0;
                        long recipient_count = Convert.ToInt64(await connection.ExecuteScalarAsync(recipient_sql, new { email_id = recipients.email_id, user_id = recipients.user_id }, tran));
                        if (recipient_count > 0)
                        {
                            //update
                            recipients.updated_on = DateTime.UtcNow;
                            recipients.updated_by = orders.user_id;
                            recipient_sql = "update recipients set name = @name,surname = @surname,title = @title,phone_number = @phone_number,updated_on = @updated_on,updated_by = @updated_by," +
                                   "is_active = 1 OUTPUT INSERTED.id where email_id = @email_id and user_id = @user_id SELECT CAST(SCOPE_IDENTITY()  as int) as id;";
                            recipient_id = Convert.ToInt64(await connection.ExecuteScalarAsync(recipient_sql, recipients, tran));

                            recipient_address_sql = "update recipients_addresses set address_type = @address_type,delivery_address1 = @delivery_address1," +
                           "delivery_address2 = @delivery_address2,delivery_address3 = @delivery_address3,delivery_city = @delivery_city," +
                           "delivery_state_id = @delivery_state_id,delivery_postal_code = @delivery_postal_code,delivery_country_id = @delivery_country_id," +
                           "delivery_is_residential = @delivery_is_residential,billing_address1 = @billing_address1,billing_address2 = @billing_address2," +
                           "billing_address3 = @billing_address3,billing_city = @billing_city,billing_state_id = @billing_state_id," +
                           "billing_postal_code = @billing_postal_code,billing_country_id = @billing_country_id,billing_is_residential = @billing_is_residential " +
                           "where recipient_id = @recipient_id";
                            recipientsAddresses.recipient_id = recipient_id;
                            Convert.ToInt64(await connection.ExecuteAsync(recipient_address_sql, recipientsAddresses, tran));
                        }
                        else
                        {
                            //insert
                            recipient_sql = "insert into recipients(user_id,name,surname,title,email_id,phone_number,created_on,updated_on,created_by,updated_by,is_active,is_deleted) " +
                           "values (@user_id,@name,@surname,@title,@email_id,@phone_number,@created_on,@updated_on,@created_by,@updated_by,@is_active,@is_deleted)  " +
                           "SELECT CAST(SCOPE_IDENTITY()  as int) as id";
                            recipients.created_on = DateTime.UtcNow;
                            recipients.created_by = orders.user_id.Value;
                            recipient_id = Convert.ToInt64(await connection.ExecuteScalarAsync(recipient_sql, recipients, tran));

                            recipientsAddresses.recipient_id = recipient_id;
                            recipient_address_sql = "insert into recipients_addresses (recipient_id,address_type,delivery_address1,delivery_address2,delivery_address3,delivery_city," +
                                "delivery_state_id,delivery_postal_code,delivery_country_id,delivery_is_residential,billing_address1,billing_address2,billing_address3," +
                                "billing_city,billing_state_id,billing_postal_code,billing_country_id,billing_is_residential)values(@recipient_id,@address_type,@delivery_address1," +
                                "@delivery_address2,@delivery_address3,@delivery_city,@delivery_state_id,@delivery_postal_code,@delivery_country_id,@delivery_is_residential," +
                                "@billing_address1,@billing_address2,@billing_address3,@billing_city,@billing_state_id,@billing_postal_code,@billing_country_id," +
                                "@billing_is_residential)";
                            await connection.ExecuteAsync(recipient_address_sql, recipientsAddresses, tran);
                        }
                        tran.Commit();
                    }
                    catch (Exception ex)
                    {
                        tran.Rollback();
                        throw ex;
                    }
                }
            }
            return orderId;
        }

        public async Task<long> UpdateOrderDetailDataAsync(Orders orders, OrdersAddresses billingAddress, OrdersAddresses deliveryAddress, List<OrdersProducts> lstProducts, Recipients recipients, RecipientsAddresses recipientsAddresses)
        {
            long orderId = orders.id;
            using (var connection = _dbCnnectionFactory.Connection())
            {
                connection.Open();
                using (var tran = connection.BeginTransaction())
                {
                    try
                    {
                        var oredr_sql = "update orders set payment_type =@payment_type, order_subtotal = @order_subtotal, order_tax = @order_tax, " +
                            "shipping_amount = @shipping_amount, order_total = @order_total,order_discount = @order_discount, " +
                            "shipping_type_mode = @shipping_type_mode, ship_transit_time = @ship_transit_time, " +
                            "order_shipping_notes = @order_shipping_notes,updated_by=@updated_by,updated_on=@updated_on where id = @id";
                        var result = await connection.ExecuteAsync(oredr_sql, orders, tran);

                        deliveryAddress.order_id = orderId;
                        deliveryAddress.order_address_type = Utilities.AddressType.Delivery;

                        var Address_sql = "update orders_addresses set order_address_type = @order_address_type, name = @name, company = @company," +
                "address_line_1 = @address_line_1,address_line_2 = @address_line_2,address_line_3 = @address_line_3,city = @city," +
                "state_id = @state_id,postal_code = @postal_code,phone_no = @phone_no,country_id = @country_id," +
                "title = @title,surname = @surname,is_residential = @is_residential,email_id = @email_id " +
                "where id = @id and order_id = @order_id";
                        await connection.ExecuteAsync(Address_sql, deliveryAddress, tran);

                        billingAddress.order_id = orderId;
                        billingAddress.order_address_type = Utilities.AddressType.Billing;
                        await connection.ExecuteAsync(Address_sql, billingAddress, tran);
                        var product_sql = "delete from orders_products where order_id=@order_id";
                        await connection.ExecuteAsync(product_sql, new { order_id = orderId }, tran);
                        product_sql = "insert into orders_products (order_id,product_id,variant_name,product_name,varient_id,unit_price,quantity," +
                           "is_active,shipment_id,created_on,created_by)" +
                           "values(@order_id,@product_id,@variant_name,@product_name,@varient_id,@unit_price,@quantity,@is_active,@shipment_id," +
                           "@created_on,@created_by)";
                        foreach (OrdersProducts data in lstProducts)
                        {
                            data.order_id = orderId;
                            await connection.ExecuteAsync(product_sql, data, tran);
                        }

                        var recipient_sql = "select c.id from recipients c where c.email_id =@email_id and c.user_id =@user_id";
                        var recipient_address_sql = "";
                        long recipient_id = 0;
                        long recipient_count = Convert.ToInt64(await connection.ExecuteScalarAsync(recipient_sql, new { email_id = recipients.email_id, user_id = recipients.user_id }, tran));
                        if (recipient_count > 0)
                        {
                            //update
                            recipients.updated_on = DateTime.UtcNow;
                            recipients.updated_by = orders.user_id;
                            recipient_sql = "update recipients set name = @name,surname = @surname,title = @title,phone_number = @phone_number,updated_on = @updated_on,updated_by = @updated_by," +
                                   "is_active = 1 OUTPUT INSERTED.id where email_id = @email_id and user_id = @user_id;";
                            recipient_id = Convert.ToInt64(await connection.ExecuteScalarAsync(recipient_sql, recipients, tran));

                            recipient_address_sql = "update recipients_addresses set address_type = @address_type,delivery_address1 = @delivery_address1," +
                           "delivery_address2 = @delivery_address2,delivery_address3 = @delivery_address3,delivery_city = @delivery_city," +
                           "delivery_state_id = @delivery_state_id,delivery_postal_code = @delivery_postal_code,delivery_country_id = @delivery_country_id," +
                           "delivery_is_residential = @delivery_is_residential,billing_address1 = @billing_address1,billing_address2 = @billing_address2," +
                           "billing_address3 = @billing_address3,billing_city = @billing_city,billing_state_id = @billing_state_id," +
                           "billing_postal_code = @billing_postal_code,billing_country_id = @billing_country_id,billing_is_residential = @billing_is_residential " +
                           "where recipient_id = @recipient_id";
                            recipientsAddresses.recipient_id = recipient_id;
                            Convert.ToInt64(await connection.ExecuteAsync(recipient_address_sql, recipientsAddresses, tran));
                        }
                        else
                        {
                            //insert
                            recipient_sql = "insert into recipients(user_id,name,surname,title,email_id,phone_number,created_on,updated_on,created_by,updated_by,is_active,is_deleted) " +
                           "values (@user_id,@name,@surname,@title,@email_id,@phone_number,@created_on,@updated_on,@created_by,@updated_by,@is_active,@is_deleted)  " +
                           "SELECT CAST(SCOPE_IDENTITY()  as int) as id";
                            recipients.created_on = DateTime.UtcNow;
                            recipients.created_by = orders.user_id.Value;
                            recipient_id = Convert.ToInt64(await connection.ExecuteScalarAsync(recipient_sql, recipients, tran));

                            recipientsAddresses.recipient_id = recipient_id;
                            recipient_address_sql = "insert into recipients_addresses (recipient_id,address_type,delivery_address1,delivery_address2,delivery_address3,delivery_city," +
                                "delivery_state_id,delivery_postal_code,delivery_country_id,delivery_is_residential,billing_address1,billing_address2,billing_address3," +
                                "billing_city,billing_state_id,billing_postal_code,billing_country_id,billing_is_residential)values(@recipient_id,@address_type,@delivery_address1," +
                                "@delivery_address2,@delivery_address3,@delivery_city,@delivery_state_id,@delivery_postal_code,@delivery_country_id,@delivery_is_residential," +
                                "@billing_address1,@billing_address2,@billing_address3,@billing_city,@billing_state_id,@billing_postal_code,@billing_country_id," +
                                "@billing_is_residential)";
                            await connection.ExecuteAsync(recipient_address_sql, recipientsAddresses, tran);
                        }
                        tran.Commit();
                    }
                    catch (Exception ex)
                    {
                        tran.Rollback();
                        throw ex;
                    }
                }
            }
            return orderId;
        }
    }
}
