﻿using DeliverIQ.Repositories.Interface;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.Repositories.Implementation
{
    public class UnitOfWork : IUnitOfWork
    {
        public UnitOfWork(
            IOrderRepository orderRepository,
            IOrderAddressRepository orderAddressRepository,
            IOrderProductsRepository orderProductRepository,
            ICountryRepository countryRepository,
            IStateRepository stateRepository,
            IRecipientRepository recipientRepository,
            IRecipientAddressRepository recipientAddressRepository,
            IProductRepository productRepository,
            IProductVariantRepository  productVariantRepository,
            IMarketplaceRepository marketplaceRepository
            )
        {
            Orders = orderRepository;
            OrderProduct = orderProductRepository;
            Countries = countryRepository;
            States = stateRepository;
            OrdersAddresses = orderAddressRepository;
            Recipients = recipientRepository;
            RecipientsAddresses = recipientAddressRepository;
            Products = productRepository;
            ProductVariants = productVariantRepository;
            Marketplaces = marketplaceRepository;
        }
        public IOrderRepository Orders { get; }
        public IOrderAddressRepository OrdersAddresses { get; }
        public IOrderProductsRepository OrderProduct { get; }

        public ICountryRepository Countries { get; set; }

        public IStateRepository States { get; set; }

        public IRecipientRepository Recipients { get; set; }

        public IRecipientAddressRepository RecipientsAddresses { get; }

        public IProductRepository Products { get; }
        public IProductVariantRepository ProductVariants { get; }

        public IMarketplaceRepository Marketplaces { get; }
    }
}
