﻿using DeliverIQ.Repositories.Interface;
using DeliverIQ.Utilities;
using Microsoft.Extensions.Configuration;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DeliverIQ.Repositories.Implementation
{
    public class DapperDbConnectionFactory : IDapperDbConnectionFactory
    {
        private readonly IConfiguration _configuration;
        public DapperDbConnectionFactory(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public IDbConnection CreateDbConnection(DatabaseConnection dbConnection)
        {
            string connectionString = null;
            switch (dbConnection)
            {
                case DatabaseConnection.PostgresConnection:
                    connectionString = _configuration.GetValue<string>("ConnectionStrings:DataAccessPostgreSqlProvider");
                    return new NpgsqlConnection(connectionString);
                case DatabaseConnection.MSSQLConnection:
                    connectionString = _configuration.GetValue<string>("ConnectionStrings:DataAccessMSSqlProvider");
                    return new SqlConnection(connectionString);
                default:
                    throw new ArgumentNullException();
                    break;
            }
        }
    }
}
