﻿using DeliverIQ.Repositories.Interface;
using DeliverIQ.Utilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace DeliverIQ.Repositories.Implementation
{
    public class DbConnectionFactory : IDbConnectionFactory
    {
        private readonly IDapperDbConnectionFactory _dbConnectionFactory;

        public DbConnectionFactory(IDapperDbConnectionFactory dbConnectionFactory)
        {
            this._dbConnectionFactory = dbConnectionFactory;
        }
        public IDbConnection Connection()
        {
            return this._dbConnectionFactory.CreateDbConnection(DatabaseConnection.MSSQLConnection);
        }
    }
}
