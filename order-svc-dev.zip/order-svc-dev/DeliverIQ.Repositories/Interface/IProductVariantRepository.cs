﻿using DeliverIQ.DataAccess.Data;
using DeliverIQ.DataAccess.Data.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.Repositories.Interface
{
    public interface IProductVariantRepository : IGenericRepository<ProductsVariants>
    {
    }
}
