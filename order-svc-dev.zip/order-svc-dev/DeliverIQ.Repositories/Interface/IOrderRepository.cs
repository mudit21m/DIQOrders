﻿using DeliverIQ.DataAccess.Data;
using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.DataAccess.Data.Model.Request;
using DeliverIQ.DataAccess.Data.Model.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Repositories.Interface
{
    public interface IOrderRepository : IGenericRepository<Orders>
    {
        //Task<IReadOnlyList<Orders>> GetAllOrders(long userId);

        //Task<Orders> GetOrderById(long userId, long orderId);
        Task<long> UpdateOrderActiveFlag(long id, bool isActive);
        Task<List<OrderDetails>> GetOrderDetailsById(long orderId);
        Task<List<OrderList>> GetOrdersByUserId(long userId, OrderFilter filters);
        //Task<List<OrderList>> GetOrdersByUserId(long userId);
        Task<long> AddOrderDetailDataAsync(Orders orders, OrdersAddresses billingAddress, OrdersAddresses deliveryAddress, List<OrdersProducts> lstProducts, Recipients recipients, RecipientsAddresses recipientsAddresses);
        Task<long> UpdateOrderDetailDataAsync(Orders orders, OrdersAddresses billingAddress, OrdersAddresses deliveryAddress, List<OrdersProducts> lstProducts, Recipients recipients, RecipientsAddresses recipientsAddresses);
    }
}
