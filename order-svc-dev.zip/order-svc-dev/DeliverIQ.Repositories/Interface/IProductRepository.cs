﻿using DeliverIQ.DataAccess.Data;
using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.DataAccess.Data.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Repositories.Interface
{
    public interface IProductRepository : IGenericRepository<Products>
    {
        Task<IReadOnlyList<Products>> GetAllProducts(long userId);

        Task<Products> GetProduct(long userId, long productId);

        Task<IReadOnlyList<ProductsVariants>> GetProductVariants(long productId);

        Task<IReadOnlyList<ProductsPhotos>> GetProductPhotos(long productId);

        Task<IReadOnlyList<ProductsFiscalGroups>> GetProductsFiscalGroups(long userId);

        Task<IReadOnlyList<Products>> GetAllProductsWithDetail(long userId);

        Task<IReadOnlyList<ProductDetails>> GetAllProductsByUserId(long userId);
    }
}
