﻿using DeliverIQ.DataAccess.Data;
using DeliverIQ.DataAccess.Data.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Repositories.Interface
{
    public interface ICountryRepository : IGenericRepository<Countries>
    {
        Task<IReadOnlyList<Countries>> GetAllCountries();
    }
}
