﻿using DeliverIQ.DataAccess.Data;
using DeliverIQ.DataAccess.Data.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Repositories.Interface
{
    public interface IOrderAddressRepository : IGenericRepository<OrdersAddresses>
    {
        //Task<IReadOnlyList<OrdersAddresses>> GetReturningCustomer(long orderid);

        //Task<IReadOnlyList<OrdersAddresses>> GetOrderAddressByOrderId(long orderId);
    }
}
