﻿using DeliverIQ.DataAccess.Data;
using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.DataAccess.Data.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Repositories.Interface
{
    public interface IRecipientRepository : IGenericRepository<Recipients>
    {
        Task<IReadOnlyList<RecipientDetails>> GetAllRecipients(long userId);

        Task<Recipients> GetRecipient(long userId, long recipientId);

        Task<Recipients> GetRecipient(long userId, string emailId);
        Task<int> CheckRecipientExist(long userId, string emailId);
        Task<long> UpdateByEmailAsync(Recipients entity);
    }
}
