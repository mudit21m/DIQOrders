﻿using DeliverIQ.Utilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace DeliverIQ.Repositories.Interface
{
    public interface IDapperDbConnectionFactory
    {
        IDbConnection CreateDbConnection(DatabaseConnection dbConnection);
    }
}
