﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace DeliverIQ.Repositories.Interface
{
    public interface IDbConnectionFactory
    {
        public IDbConnection Connection();
    }
}
