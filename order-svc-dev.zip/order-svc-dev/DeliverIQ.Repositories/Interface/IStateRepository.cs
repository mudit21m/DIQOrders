﻿using DeliverIQ.DataAccess.Data;
using DeliverIQ.DataAccess.Data.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Repositories.Interface
{
    public interface IStateRepository : IGenericRepository<States>
    {
        Task<IReadOnlyList<States>> GetStatesByCountryId(long countryId);
    }
}
