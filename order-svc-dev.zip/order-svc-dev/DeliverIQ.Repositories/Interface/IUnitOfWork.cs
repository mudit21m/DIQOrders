﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.Repositories.Interface
{
    public interface IUnitOfWork
    {
        IOrderRepository Orders { get; }
        IOrderProductsRepository OrderProduct { get; }
        IOrderAddressRepository OrdersAddresses { get; }

        ICountryRepository Countries { get; }

        IStateRepository States { get; }

        IRecipientRepository Recipients { get; }

        IRecipientAddressRepository RecipientsAddresses { get; }

        IProductRepository Products { get; }
        IProductVariantRepository ProductVariants { get; }

        IMarketplaceRepository Marketplaces { get; }
    }
}
