﻿using Microsoft.Extensions.DependencyInjection;
using DeliverIQ.Repositories.Implementation;
using DeliverIQ.Repositories.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using DeliverIQ.DataAccess.Data;

namespace DeliverIQ.Repositories
{
    public static class RepositoriesInjection
    {
        public static IServiceCollection RegisterRepositories(this IServiceCollection services)
        {
            services.AddTransient<IUnitOfWork, UnitOfWork>();
            services.AddTransient<IDapperDbConnectionFactory, DapperDbConnectionFactory>();
            services.AddTransient<IDbConnectionFactory, DbConnectionFactory>();



            services.AddScoped<IOrderRepository, OrderRepository>();
            services.AddScoped<IOrderProductsRepository, OrderProductsRepository>();
            services.AddScoped<IOrderAddressRepository, OrderAddressRepository>();
            services.AddScoped<ICountryRepository, CountryRepository>();
            services.AddScoped<IStateRepository, StateRepository>();
            services.AddScoped<IRecipientRepository, RecipientRepository>();
            services.AddScoped<IRecipientAddressRepository, RecipientAddressRepository>();
            services.AddScoped<IProductRepository, ProductRepository>();
            services.AddScoped<IProductVariantRepository, ProductVariantRepository>();
            services.AddScoped<IMarketplaceRepository, MarketplaceRepository>();
            //  services.RegisterDataAccess();
            return services;
        }
    }
}
