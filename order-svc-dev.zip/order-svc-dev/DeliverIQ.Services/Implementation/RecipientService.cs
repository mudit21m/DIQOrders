﻿using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.Repositories.Interface;
using DeliverIQ.Services.Interface;
using DeliverIQ.Services.Model.Request;
using DeliverIQ.Utilities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using DeliverIQ.Services.Model.Response;

namespace DeliverIQ.Services.Implementation
{
    public class RecipientService : IRecipientService
    {
        private readonly IUnitOfWork unitOfWork;
        public RecipientService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public async Task<IReadOnlyList<RecipientDetails>> GetAllRecipients(long userId)
        {
            List<RecipientDetails> detail = new List<RecipientDetails>();

            var data = await unitOfWork.Recipients.GetAllRecipients(userId);

            RecipientDetails recipient = null;

            foreach (var item in data)
            {
                recipient = new RecipientDetails();
                recipient.EmailId = item.email_id;
                recipient.Name = item.name;
                recipient.SurName = item.surname;
                recipient.PhoneNumber = item.phone_number;
                recipient.Title = item.title;
                recipient.RecipientId = item.recipient_id;

                recipient.Address.Id = item.address_id;
                recipient.Address.BillingAddress1 = item.billing_address1;
                recipient.Address.BillingAddress2 = item.billing_address2;
                recipient.Address.BillingAddress3 = item.billing_address3;
                recipient.Address.BillingCity = item.billing_city;
                recipient.Address.BillingCountryId = item.billing_country_id;
                recipient.Address.BillingIsResidential = item.billing_is_residential;
                recipient.Address.BillingPostalCode = item.billing_postal_code;
                recipient.Address.BillingStateId = item.billing_state_id;
                recipient.Address.DeliveryAddress1 = item.delivery_address1;
                recipient.Address.DeliveryAddress2 = item.delivery_address2;
                recipient.Address.DeliveryAddress3 = item.delivery_address3;
                recipient.Address.DeliveryCity = item.delivery_city;
                recipient.Address.DeliveryCountryId = item.delivery_country_id;
                recipient.Address.DeliveryIsResidential = item.delivery_is_residential;
                recipient.Address.DeliveryPostalCode = item.delivery_postal_code;
                recipient.Address.DeliveryStateId = item.delivery_state_id;

                detail.Add(recipient);
            }
            
            return detail;
        }

        public async Task<RecipientDetail> GetRecipientDetail(long userId, long recipientId)
        {
            RecipientDetail detail = new RecipientDetail();
            var customer = await unitOfWork.Recipients.GetRecipient(userId, recipientId);
            var addresses = await unitOfWork.RecipientsAddresses.GetRecipientAddresses(recipientId);

            detail = SyncRecipientDetail(customer, addresses);

            return detail;
        }

        public async Task<RecipientDetail> GetRecipientDetail(long userId, string emailId)
        {
            RecipientDetail detail = new RecipientDetail();
            var customer = await unitOfWork.Recipients.GetRecipient(userId, emailId);

            var addresses = await unitOfWork.RecipientsAddresses.GetRecipientAddresses(customer?.id);

            detail = SyncRecipientDetail(customer, addresses);

            return detail;
        }

        private RecipientDetail SyncRecipientDetail(Recipients customer, IReadOnlyList<RecipientsAddresses> addresses)
        {
            RecipientDetail detail = new RecipientDetail();
            if (customer != null)
            {
                detail.EmailId = customer.email_id;
                detail.Name = customer.name;
                detail.SurName = customer.surname;
                detail.PhoneNumber = customer.phone_number;
                detail.Title = customer.title;
                detail.RecipientId = customer.id;
                detail.UserId = customer.user_id;
            }

            RecipientAddressDetail addressDetail;
            foreach (var item in addresses)
            {
                addressDetail = new RecipientAddressDetail();
                //billing
                addressDetail.AddressId = item.id;
                addressDetail.BillingAddress1 = item.billing_address1;
                addressDetail.BillingAddress2 = item.billing_address2;
                addressDetail.BillingAddress3 = item.billing_address3;
                addressDetail.BillingCity = item.billing_city;
                addressDetail.BillingCountryId = item.billing_country_id;
                addressDetail.BillingIsResidential = item.billing_is_residential;
                addressDetail.BillingPostalCode = item.billing_postal_code;
                addressDetail.BillingStateId = item.billing_state_id;
                //delivery
                addressDetail.DeliveryAddress1 = item.delivery_address1;
                addressDetail.DeliveryAddress2 = item.delivery_address2;
                addressDetail.DeliveryAddress3 = item.delivery_address3;
                addressDetail.DeliveryCity = item.delivery_city;
                addressDetail.DeliveryCountryId = item.delivery_country_id;
                addressDetail.DeliveryIsResidential = item.delivery_is_residential;
                addressDetail.DeliveryPostalCode = item.delivery_postal_code;
                addressDetail.DeliveryStateId = item.delivery_state_id;
                detail.RecipientAddresses.Add(addressDetail);
            }

            return detail;
        }
    }
}
