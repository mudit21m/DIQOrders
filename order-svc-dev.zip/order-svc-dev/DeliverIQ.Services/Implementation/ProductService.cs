﻿using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.Repositories.Interface;
using DeliverIQ.Services.Interface;
using DeliverIQ.Services.Model.Response;
using DeliverIQ.Services.Model.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace DeliverIQ.Services.Implementation
{
    public class ProductService : IProductService
    {
        private readonly IUnitOfWork unitOfWork;
        public ProductService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public async Task<IReadOnlyList<ProductsFiscalGroups>> GetProductsFiscalGroups(long userId)
        {
            return await unitOfWork.Products.GetProductsFiscalGroups(userId);
        }

        public async Task<List<ProductDetail>> GetAllProducts(long userId)
        {
            var products = await unitOfWork.Products.GetAllProducts(userId);

            List<ProductDetail> productList = new List<ProductDetail>();

            ProductDetail detail;
            foreach (var product in products)
            {
                detail = new ProductDetail();

                detail.ProductId = product.id;
                detail.Barcode = product.barcode;
                detail.BarcodeTypeId = product.barcode_type_id;
                detail.BasePrice = product.base_price;
                detail.CurrencyId = product.currency_id;
                detail.DiqProductCode = product.diq_product_code;
                detail.HasVariant = product.has_variant;
                detail.ProductDescription = product.product_description;
                detail.ProductFiscalGroupId = product.product_fiscal_group_id;
                detail.ProductName = product.product_name;
                detail.ProductStatus = product.product_status;
                //detail.UserId = product.user_id;
                detail.ProductTax = product.product_tax;

                var productPhotos = await unitOfWork.Products.GetProductPhotos(product.id);

                var productVariants = await unitOfWork.Products.GetProductVariants(product.id);

                if (productPhotos.Count > 0)
                {
                    detail.ProductPhotos = new List<ProductPhoto>();

                    foreach (var item in productPhotos)
                    {
                        ProductPhoto photo = new ProductPhoto();
                        photo.ImageUrl = item.image_url;
                        photo.ProductId = item.product_id;
                        photo.VariantId = item.variant_id;

                        detail.ProductPhotos.Add(photo);
                    }
                }

                if (productVariants.Count > 0)
                {
                    detail.ProductVariants = new List<ProductVariant>();

                    foreach (var item in productVariants)
                    {
                        ProductVariant variant = new ProductVariant();
                        variant.AdditionalDescription = item.additional_description;
                        variant.Barcode = item.barcode;
                        variant.BarcodeTypeId = item.barcode_type_id;
                        variant.IsSeprateBarcode = item.is_seprate_barcode;
                        variant.ProductId = item.product_id;
                        variant.VariantName = item.variant_name;

                        detail.ProductVariants.Add(variant);
                    }
                }

                productList.Add(detail);
            }

            return productList;
        }

        public async Task<List<ProductDetail>> GetProductsByUserId(long userId)
        {
            var data = await unitOfWork.Products.GetAllProductsByUserId(userId);

            List<ProductDetail> productList = new List<ProductDetail>();

            ProductDetail detail;
            foreach (var item in data.Select(s => s.id).Distinct().OrderBy(o => o))
            {
                detail = new ProductDetail();
                var product = data.First(x => x.id == item);
                detail.ProductId = product.id;
                detail.Barcode = product.barcode;
                detail.BarcodeTypeId = product.barcode_type_id;
                detail.BasePrice = product.base_price;
                detail.CurrencyId = product.currency_id;
                detail.DiqProductCode = product.diq_product_code;
                detail.HasVariant = product.has_variant;
                detail.ProductDescription = product.product_description;
                detail.ProductFiscalGroupId = product.product_fiscal_group_id;
                detail.ProductName = product.product_name;
                detail.ProductStatus = product.product_status;
                //detail.UserId = product.user_id;
                detail.ProductTax = product.product_tax;

                foreach (var itemD in data.Where(x => x.id == item).ToList())
                {
                    if (!string.IsNullOrWhiteSpace(itemD.image_url))
                    {
                        ProductPhoto photo = new ProductPhoto();
                        photo.Id = itemD.image_id;
                        photo.ImageUrl = itemD.image_url;
                        photo.ProductId = itemD.image_product_id;
                        photo.VariantId = itemD.image_variant_id;

                        detail.ProductPhotos.Add(photo);
                    }

                    if (itemD.variant_id > 0)
                    {
                        ProductVariant variant = new ProductVariant();
                        variant.AdditionalDescription = itemD.variant_additional_description;
                        variant.Barcode = itemD.variant_barcode;
                        variant.BarcodeTypeId = itemD.variant_barcode_type_id;
                        variant.IsSeprateBarcode = itemD.variant_is_seprate_barcode;
                        variant.ProductId = itemD.variant_product_id;
                        variant.VariantName = itemD.variant_name;
                        variant.Id = itemD.variant_id;

                        detail.ProductVariants.Add(variant);
                    }

                    if (itemD.package_id > 0)
                    {
                        ProductPackage package = new ProductPackage();
                        package.Id = itemD.package_id;
                        package.DimUnit = itemD.package_dim_unit;
                        package.Height = itemD.package_height;
                        package.Length = itemD.package_length;
                        package.Width = itemD.package_width;
                        package.VariantId = itemD.package_variant_id;
                        package.Weight = itemD.package_weight;
                        package.WeightUnit = itemD.package_weight_unit;

                        detail.ProductPackages.Add(package);
                    }
                }

                productList.Add(detail);
            }

            return productList;
        }

        public async Task<ProductDetail> GetProductDetail(long userId, long productId)
        {
            ProductDetail detail = new ProductDetail();
            try
            {

                var product = await unitOfWork.Products.GetProduct(userId, productId);

                if (product != null)
                {
                    var productPhotos = await unitOfWork.Products.GetProductPhotos(product.id);

                    var productVariants = await unitOfWork.Products.GetProductVariants(product.id);

                    detail.ProductId = product.id;
                    detail.Barcode = product.barcode;
                    detail.BarcodeTypeId = product.barcode_type_id;
                    detail.BasePrice = product.base_price;
                    detail.CurrencyId = product.currency_id;
                    detail.DiqProductCode = product.diq_product_code;
                    detail.HasVariant = product.has_variant;
                    detail.ProductDescription = product.product_description;
                    detail.ProductFiscalGroupId = product.product_fiscal_group_id;
                    detail.ProductName = product.product_name;
                    detail.ProductStatus = product.product_status;
                    // detail.UserId = product.user_id;
                    detail.ProductTax = product.product_tax;


                    if (productPhotos.Count > 0)
                    {
                        detail.ProductPhotos = new List<ProductPhoto>();

                        foreach (var item in productPhotos)
                        {
                            ProductPhoto photo = new ProductPhoto();
                            photo.ImageUrl = item.image_url;
                            photo.ProductId = item.product_id;
                            photo.VariantId = item.variant_id;

                            detail.ProductPhotos.Add(photo);
                        }
                    }

                    if (productVariants.Count > 0)
                    {
                        detail.ProductVariants = new List<ProductVariant>();

                        foreach (var item in productVariants)
                        {
                            ProductVariant variant = new ProductVariant();
                            variant.AdditionalDescription = item.additional_description;
                            variant.Barcode = item.barcode;
                            variant.BarcodeTypeId = item.barcode_type_id;
                            variant.IsSeprateBarcode = item.is_seprate_barcode;
                            variant.ProductId = item.product_id;
                            variant.VariantName = item.variant_name;

                            detail.ProductVariants.Add(variant);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string message = ex.Message;
            }

            return detail;
        }

        public async Task<int> Add(CreateEditProduct product)
        {
            try
            {
                if (product != null)
                {

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return 1;
        }
    }
}
