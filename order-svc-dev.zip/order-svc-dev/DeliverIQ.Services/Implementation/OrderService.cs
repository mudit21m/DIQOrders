﻿using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.DataAccess.Data.Model.Request;
using DeliverIQ.DataAccess.Data.Model.Response;
using DeliverIQ.Repositories.Interface;
using DeliverIQ.Services.Interface;
using DeliverIQ.Services.Model.Request;
using DeliverIQ.Services.Model.Response;
using DeliverIQ.Utilities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Services.Implementation
{
    public class OrderService : IOrderService
    {
        private readonly IUnitOfWork unitOfWork;
        public OrderService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public async Task<BaseResponse<List<OrdersData>>> GetOrdersByUserId(long userId, OrderFilter orderFilter)
        {
            BaseResponse<List<OrdersData>> response = new BaseResponse<List<OrdersData>>();

            try
            {
                List<OrdersData> orders = new List<OrdersData>();

                var data = await unitOfWork.Orders.GetOrdersByUserId(userId, orderFilter);

                OrdersData orderDetail = null;
                if (data != null && data.Count > 0)
                {
                    foreach (var item in data.Select(s => s.id).Distinct().OrderBy(o => o))
                    {
                        orderDetail = new OrdersData();

                        var orderData = data.First(x => x.id == item);

                        orderDetail.OrderId = orderData.id;
                        orderDetail.DIQOrderNumber = orderData.diq_order_number;
                        orderDetail.SourceId = orderData.marketplace_order_number;
                        orderDetail.OrderDate = orderData.order_created_date;
                        orderDetail.OrderStatus = ((OrderStatus)orderData.order_status_id).ToDescription();
                        orderDetail.OrderStatusId = orderData.order_status_id;
                        orderDetail.OrderTotal = orderData.order_total;
                        orderDetail.RecipientName = orderData.name + " " + orderData.surname;
                        orderDetail.PostalCode = orderData.del_postal_code;
                        orderDetail.CountryName = orderData.del_country_name;
                        orderDetail.MarketPlaceId = orderData.marketplace_id;
                        orderDetail.MarketPlaceName = orderData.marketplace_name;

                        orders.Add(orderDetail);

                    }
                }

                response.StatusCode = HttpStatusCode.OK;
                response.Message = "Success";
                response.Data = orders;
            }
            catch (Exception ex)
            {
                response.StatusCode = HttpStatusCode.InternalServerError;
                response.Message = ex.Message;
            }

            return response;
        }

        //private OrderFilterRequest SetFilters(OrderFilter orderFilter, OrderFilterRequest filters)
        //{
        //    filters.Amount.Filter = orderFilter.Amount.Filter;
        //    filters.Amount.Sort = orderFilter.Amount.Sort;
        //    filters.Amount.Index = orderFilter.Amount.Index;

        //    filters.Channel.Filter = orderFilter.Channel.Filter;
        //    filters.Channel.Sort = orderFilter.Channel.Sort;
        //    filters.Channel.Index = orderFilter.Channel.Index;

        //    filters.CreatedDate.Filter = orderFilter.CreatedDate.Filter;
        //    filters.CreatedDate.Sort = orderFilter.CreatedDate.Sort;
        //    filters.CreatedDate.Index = orderFilter.CreatedDate.Index;

        //    filters.Customer.Filter = orderFilter.Customer.Filter;
        //    filters.Customer.Sort = orderFilter.Customer.Sort;
        //    filters.Customer.Index = orderFilter.Customer.Index;

        //    filters.Order.Filter = orderFilter.Order.Filter;
        //    filters.Order.Sort = orderFilter.Order.Sort;
        //    filters.Order.Index = orderFilter.Order.Index;

        //    filters.SourceId.Filter = orderFilter.SourceId.Filter;
        //    filters.SourceId.Sort = orderFilter.SourceId.Sort;
        //    filters.SourceId.Index = orderFilter.SourceId.Index;

        //    filters.Status.Filter = orderFilter.Status.Filter;
        //    filters.Status.Sort = orderFilter.Status.Sort;
        //    filters.Status.Index = orderFilter.Status.Index;

        //    return filters;
        //}

        public async Task<Orders> GetById(int id)
        {
            var data = await unitOfWork.Orders.GetByIdAsync(id);
            return data;
        }

        public async Task<CreateOrder> GetOrderDetailsById(int id)
        {
            CreateOrder orderDetail = null;
            var data = await unitOfWork.Orders.GetOrderDetailsById(id);
            if (data != null && data.Count > 0)
            {
                var orderData = data.First();
                #region Add order
                orderDetail = new CreateOrder();
                orderDetail.OrderId = orderData.id;
                orderDetail.PaymentType =(PaymentTypes)orderData.payment_type;
                orderDetail.SubTotal = orderData.order_subtotal;
                orderDetail.TaxTotal = orderData.order_tax;
                orderDetail.ShippingMethodTotal = orderData.shipping_amount;
                orderDetail.Total = orderData.order_total;
                orderDetail.DiscountTotal = orderData.order_discount;
                orderDetail.ShippingDetails.ShippingId = orderData.shipment_id;
                orderDetail.ShippingDetails.ExpectedDeliveryDate = orderData.ship_transit_time;
                orderDetail.ShippingDetails.Notes = orderData.order_shipping_notes;
                #endregion

                #region set the order address
                orderDetail.Address.DeliveryAddress.Id = orderData.del_id;
                orderDetail.Address.DeliveryAddress.CountryId = orderData.del_country_id;
                orderDetail.Address.DeliveryAddress.Address1 = orderData.del_address_line_1;
                orderDetail.Address.DeliveryAddress.Address2 = orderData.del_address_line_2;
                orderDetail.Address.DeliveryAddress.Address3 = orderData.del_address_line_3;
                orderDetail.Address.DeliveryAddress.City = orderData.del_city;
                orderDetail.Address.DeliveryAddress.PostalCode = orderData.del_postal_code;
                orderDetail.Address.DeliveryAddress.IsResidential = orderData.del_is_residential;
                orderDetail.Address.DeliveryAddress.StateId = orderData.del_state_id;

                orderDetail.Address.BillingAddress.Id = orderData.bill_id;
                orderDetail.Address.BillingAddress.CountryId = orderData.bill_country_id;
                orderDetail.Address.BillingAddress.Address1 = orderData.bill_address_line_1;
                orderDetail.Address.BillingAddress.Address2 = orderData.bill_address_line_2;
                orderDetail.Address.BillingAddress.Address3 = orderData.bill_address_line_3;
                orderDetail.Address.BillingAddress.City = orderData.bill_city;
                orderDetail.Address.BillingAddress.PostalCode = orderData.bill_postal_code;
                orderDetail.Address.BillingAddress.IsResidential = orderData.bill_is_residential;
                orderDetail.Address.BillingAddress.StateId = orderData.bill_state_id;

                #endregion

                #region set the order address
                orderDetail.ContactDetails.Name = orderData.name;
                orderDetail.ContactDetails.SurName = orderData.surname;
                orderDetail.ContactDetails.Title = (TitleMaster)orderData.title;
                orderDetail.ContactDetails.Phone = orderData.phone_no;
                orderDetail.ContactDetails.Email = orderData.email_id;
                #endregion

                #region set the order product 

                foreach (var productItem in data)
                {
                    CreateOrderOrderItem idata = new CreateOrderOrderItem();
                    idata.Id = productItem.product_id;
                    idata.VariantId = productItem.varient_id;
                    idata.ProductId = productItem.product_id;
                    idata.Quantity = productItem.quantity;
                    orderDetail.OrderItems.Add(idata);
                }
                #endregion
            }
            return orderDetail;
        }
        public async Task<BaseResponse<int>> AddOrder(CreateOrder order, long userId)
        {
            BaseResponse<int> response = new BaseResponse<int>();
            long orderId = 0;
            OrdersAddresses BillingAddess = new OrdersAddresses();
            OrdersAddresses DeliveryAddess = new OrdersAddresses();
            List<OrdersProducts> lstProducts = new List<OrdersProducts>();
            Recipients recipients = new Recipients();
            RecipientsAddresses recipientsAddresses = new RecipientsAddresses();
            try
            {
                if (order != null)
                {
                    #region Add Order
                    DateTime created = DateTime.UtcNow;
                    Orders orderData = new Orders();
                    orderData.diq_order_number = Utilities.Common.GenerateOrderNumber(userId);//Query
                    orderData.order_date = DateTime.UtcNow;
                    orderData.order_created_date = DateTime.UtcNow;
                    orderData.ship_by_date = DateTime.UtcNow;//Query
                    orderData.order_status_id = OrderStatus.Unapproved;
                    orderData.order_total = order.Total;//Grand total of complete order
                    orderData.shipping_amount = order.ShippingMethodTotal;
                    orderData.is_fulfilled = false;
                    orderData.order_modification_status = 1;//Query 
                    orderData.shipping_type_mode = order.ShippingDetails?.ShippingId;
                    orderData.ship_transit_time = order.ShippingDetails?.ExpectedDeliveryDate;
                    orderData.order_subtotal = order.SubTotal;
                    orderData.order_discount = order.DiscountTotal;
                    orderData.order_discount_type = "order_discount_type";//What is discount type
                    orderData.order_tax = order.TaxTotal;
                    orderData.order_shipping_notes = order.ShippingDetails?.Notes;
                    orderData.payment_type = order.PaymentType;//enum Prepaid,CashOnDelivery
                    orderData.created_by = userId;
                    orderData.created_on = created;
                    orderData.user_id = userId;//What is customer id
                    #endregion
                    #region set the order address
                    if (order.Address?.BillingAddress != null && order.ContactDetails != null)
                    {
                        //set the DeliveryAddress
                        DeliveryAddess.order_address_type = Utilities.AddressType.Delivery;
                        DeliveryAddess.country_id = order.Address.DeliveryAddress.CountryId;
                        DeliveryAddess.address_line_1 = order.Address.DeliveryAddress.Address1;
                        DeliveryAddess.address_line_2 = order.Address.DeliveryAddress.Address2;
                        DeliveryAddess.address_line_3 = order.Address.DeliveryAddress.Address3;
                        DeliveryAddess.city = order.Address.DeliveryAddress.City;
                        DeliveryAddess.postal_code = order.Address.DeliveryAddress.PostalCode;
                        DeliveryAddess.is_residential = order.Address.DeliveryAddress.IsResidential;
                        DeliveryAddess.state_id = order.Address.DeliveryAddress.StateId;
                        DeliveryAddess.order_id = orderId;
                        DeliveryAddess.name = order.ContactDetails.Name;
                        DeliveryAddess.surname = order.ContactDetails.SurName;
                        DeliveryAddess.phone_no = order.ContactDetails.Phone;
                        DeliveryAddess.email_id = order.ContactDetails.Email;
                        DeliveryAddess.title = (int)order.ContactDetails.Title;
                        //await unitOfWork.OrdersAddresses.AddAsync(BillingAddess);
                        if (order.Address.UseAsSameForBilling)
                        {
                            BillingAddess = DeliveryAddess;
                        }
                        else
                        {
                            BillingAddess = new OrdersAddresses();
                            BillingAddess.order_address_type = Utilities.AddressType.Delivery;
                            BillingAddess.country_id = order.Address.BillingAddress.CountryId;
                            BillingAddess.state_id = order.Address.BillingAddress.StateId;
                            BillingAddess.address_line_1 = order.Address.BillingAddress.Address1;
                            BillingAddess.address_line_2 = order.Address.BillingAddress.Address2;
                            BillingAddess.address_line_3 = order.Address.BillingAddress.Address3;
                            BillingAddess.city = order.Address.BillingAddress.City;
                            BillingAddess.postal_code = order.Address.BillingAddress.PostalCode;
                            BillingAddess.is_residential = order.Address.BillingAddress.IsResidential;
                            BillingAddess.order_id = orderId;
                            BillingAddess.name = order.ContactDetails.Name;
                            BillingAddess.surname = order.ContactDetails.SurName;
                            BillingAddess.phone_no = order.ContactDetails.Phone;
                            BillingAddess.email_id = order.ContactDetails.Email;
                            BillingAddess.title = (int)order.ContactDetails.Title;
                        }

                    }
                    #endregion
                    #region Add and update the recipient details
                    if (order.ContactDetails != null)
                    {
                        //Recipient

                        recipients.user_id = userId;
                        recipients.name = order.ContactDetails.Name;
                        recipients.surname = order.ContactDetails.SurName;
                        recipients.title = (int)order.ContactDetails.Title;
                        recipients.phone_number = order.ContactDetails.Phone;
                        recipients.email_id = order.ContactDetails.Email;
                        recipients.is_deleted = false;
                        recipients.is_active= true;
                        //RecipientsAddresses

                        if (order.Address?.BillingAddress != null)
                        {
                            recipientsAddresses.billing_address1 = order.Address.BillingAddress.Address1;
                            recipientsAddresses.billing_address2 = order.Address.BillingAddress.Address2;
                            recipientsAddresses.billing_address3 = order.Address.BillingAddress.Address3;
                            recipientsAddresses.billing_city = order.Address.BillingAddress.City;
                            recipientsAddresses.billing_country_id = order.Address.BillingAddress.CountryId;
                            recipientsAddresses.billing_is_residential = order.Address.BillingAddress.IsResidential;
                            recipientsAddresses.billing_postal_code = order.Address.BillingAddress.PostalCode;
                            recipientsAddresses.billing_state_id = order.Address.BillingAddress.StateId;

                            recipientsAddresses.delivery_address1 = order.Address.DeliveryAddress.Address1;
                            recipientsAddresses.delivery_address2 = order.Address.DeliveryAddress.Address2;
                            recipientsAddresses.delivery_address3 = order.Address.DeliveryAddress.Address3;
                            recipientsAddresses.delivery_city = order.Address.DeliveryAddress.City;
                            recipientsAddresses.delivery_country_id = order.Address.DeliveryAddress.CountryId;
                            recipientsAddresses.delivery_is_residential = order.Address.DeliveryAddress.IsResidential;
                            recipientsAddresses.delivery_postal_code = order.Address.DeliveryAddress.PostalCode;
                            recipientsAddresses.delivery_state_id = order.Address.DeliveryAddress.StateId;
                        }
                    }
                    #endregion
                    #region set the order product 
                    if (order.OrderItems?.Count > 0)
                    {
                        foreach (var OrderItem in order.OrderItems)
                        {
                            Products products = await unitOfWork.Products.GetProduct(userId, OrderItem.ProductId);
                            if (products != null)
                            {
                                ProductsVariants productsVariants = null;
                                if (OrderItem.VariantId > 0)
                                    productsVariants = await unitOfWork.ProductVariants.GetByIdAsync(OrderItem.VariantId);
                                OrdersProducts orderProduct = new OrdersProducts();
                                orderProduct.order_id = orderId;
                                orderProduct.product_id = OrderItem.ProductId;
                                orderProduct.variant_name = productsVariants?.variant_name;
                                orderProduct.product_name = products.product_name;
                                orderProduct.varient_id = OrderItem.VariantId;
                                orderProduct.unit_price = products.base_price;
                                orderProduct.quantity = OrderItem.Quantity;
                                orderProduct.shipment_id = 0;
                                orderProduct.created_by = userId;
                                orderProduct.created_on = created;
                                orderProduct.is_active= true;
                                orderProduct.is_deleted = false;
                                lstProducts.Add(orderProduct);
                            }
                        }
                    }
                    else
                    {
                        throw new Exception("product and varient not exist.");
                    }
                    #endregion
                    orderId = await unitOfWork.Orders.AddOrderDetailDataAsync(orderData, BillingAddess, DeliveryAddess, lstProducts, recipients, recipientsAddresses);
                }
                else
                {
                    response.StatusCode = HttpStatusCode.BadRequest;
                    response.Message = "Bad Request";
                    return response;
                }
            }
            catch (Exception ex)
            {
                response.StatusCode = HttpStatusCode.InternalServerError;
                response.Message = ex.Message;
                return response;
            }
            response.StatusCode = HttpStatusCode.OK;
            response.Message = "Success";
            return response;
        }

        //public async Task<IReadOnlyList<OrdersAddresses>> GetCustomers(int orderid)
        //{
        //    var data = await unitOfWork.OrdersAddresses.GetReturningCustomer(orderid);
        //    return data;
        //}

        public async Task<BaseResponse<int>> Update(CreateOrder orderData, long userId)
        {
            BaseResponse<int> response = new BaseResponse<int>();
            Orders orderDetail = new Orders();
            OrdersAddresses BillingAddess = new OrdersAddresses();
            OrdersAddresses DeliveryAddess = new OrdersAddresses();
            List<OrdersProducts> lstProducts = new List<OrdersProducts>();
            Recipients recipients = new Recipients();
            RecipientsAddresses recipientsAddresses = new RecipientsAddresses();
            DateTime updated = DateTime.UtcNow;
            long orderId = 0;
            try
            {
                if (orderData != null && orderData.OrderId != null)
                {
                    #region Update Order
                    orderDetail.id = orderData.OrderId.Value;
                    orderDetail.payment_type = orderData.PaymentType;
                    orderDetail.order_subtotal = orderData.SubTotal;
                    orderDetail.order_tax = orderData.TaxTotal;
                    orderDetail.shipping_amount = orderData.ShippingMethodTotal;
                    orderDetail.order_total = orderData.Total;
                    orderDetail.order_discount = orderData.DiscountTotal;
                    orderDetail.shipping_type_mode = orderData.ShippingDetails.ShippingId;
                    orderDetail.ship_transit_time = orderData.ShippingDetails.ExpectedDeliveryDate;
                    orderDetail.order_shipping_notes = orderData.ShippingDetails.Notes;
                    orderDetail.updated_on = updated;
                    orderDetail.updated_by = userId;
                    #endregion
                    #region set the order address
                    if (orderData.Address?.BillingAddress != null && orderData.ContactDetails != null)
                    {
                        //set the DeliveryAddress
                        DeliveryAddess.id = orderData.Address.DeliveryAddress.Id.Value;
                        DeliveryAddess.order_address_type = Utilities.AddressType.Delivery;
                        DeliveryAddess.country_id = orderData.Address.DeliveryAddress.CountryId;
                        DeliveryAddess.address_line_1 = orderData.Address.DeliveryAddress.Address1;
                        DeliveryAddess.address_line_2 = orderData.Address.DeliveryAddress.Address2;
                        DeliveryAddess.address_line_3 = orderData.Address.DeliveryAddress.Address3;
                        DeliveryAddess.city = orderData.Address.DeliveryAddress.City;
                        DeliveryAddess.postal_code = orderData.Address.DeliveryAddress.PostalCode;
                        DeliveryAddess.is_residential = orderData.Address.DeliveryAddress.IsResidential;
                        DeliveryAddess.state_id = orderData.Address.DeliveryAddress.StateId;
                        DeliveryAddess.order_id = orderId;
                        DeliveryAddess.name = orderData.ContactDetails.Name;
                        DeliveryAddess.surname = orderData.ContactDetails.SurName;
                        DeliveryAddess.phone_no = orderData.ContactDetails.Phone;
                        DeliveryAddess.email_id = orderData.ContactDetails.Email;
                        DeliveryAddess.title = (int)orderData.ContactDetails.Title;
                        if (orderData.Address.UseAsSameForBilling)
                        {
                            //set the delivery address
                            BillingAddess.Equals(DeliveryAddess);
                            BillingAddess.id = orderData.Address.BillingAddress.Id.Value;
                        }
                        else
                        {
                            BillingAddess.id = orderData.Address.BillingAddress.Id.Value;
                            BillingAddess.order_address_type = Utilities.AddressType.Billing;
                            BillingAddess.country_id = orderData.Address.BillingAddress.CountryId;
                            BillingAddess.state_id = orderData.Address.BillingAddress.StateId;
                            BillingAddess.address_line_1 = orderData.Address.BillingAddress.Address1;
                            BillingAddess.address_line_2 = orderData.Address.BillingAddress.Address2;
                            BillingAddess.address_line_3 = orderData.Address.BillingAddress.Address3;
                            BillingAddess.city = orderData.Address.BillingAddress.City;
                            BillingAddess.postal_code = orderData.Address.BillingAddress.PostalCode;
                            BillingAddess.is_residential = orderData.Address.BillingAddress.IsResidential;
                            BillingAddess.order_id = orderId;
                            BillingAddess.name = orderData.ContactDetails.Name;
                            BillingAddess.surname = orderData.ContactDetails.SurName;
                            BillingAddess.phone_no = orderData.ContactDetails.Phone;
                            BillingAddess.email_id = orderData.ContactDetails.Email;
                            BillingAddess.title = (int)orderData.ContactDetails.Title;
                        }
                    }
                    #endregion
                    #region Add and update the recipient details
                    if (orderData.ContactDetails != null)
                    {
                        //Recipient
                        recipients.user_id = userId;
                        recipients.name = orderData.ContactDetails.Name;
                        recipients.surname = orderData.ContactDetails.SurName;
                        recipients.title =(int)orderData.ContactDetails.Title;
                        recipients.phone_number = orderData.ContactDetails.Phone;
                        recipients.email_id = orderData.ContactDetails.Email;
                        //RecipientsAddresses
                        if (orderData.Address?.BillingAddress != null)
                        {
                            recipientsAddresses.billing_address1 = orderData.Address.BillingAddress.Address1;
                            recipientsAddresses.billing_address2 = orderData.Address.BillingAddress.Address2;
                            recipientsAddresses.billing_address3 = orderData.Address.BillingAddress.Address3;
                            recipientsAddresses.billing_city = orderData.Address.BillingAddress.City;
                            recipientsAddresses.billing_country_id = orderData.Address.BillingAddress.CountryId;
                            recipientsAddresses.billing_is_residential = orderData.Address.BillingAddress.IsResidential;
                            recipientsAddresses.billing_postal_code = orderData.Address.BillingAddress.PostalCode;
                            recipientsAddresses.billing_state_id = orderData.Address.BillingAddress.StateId;

                            recipientsAddresses.delivery_address1 = orderData.Address.DeliveryAddress.Address1;
                            recipientsAddresses.delivery_address2 = orderData.Address.DeliveryAddress.Address2;
                            recipientsAddresses.delivery_address3 = orderData.Address.DeliveryAddress.Address3;
                            recipientsAddresses.delivery_city = orderData.Address.DeliveryAddress.City;
                            recipientsAddresses.delivery_country_id = orderData.Address.DeliveryAddress.CountryId;
                            recipientsAddresses.delivery_is_residential = orderData.Address.DeliveryAddress.IsResidential;
                            recipientsAddresses.delivery_postal_code = orderData.Address.DeliveryAddress.PostalCode;
                            recipientsAddresses.delivery_state_id = orderData.Address.DeliveryAddress.StateId;
                        }
                    }
                    #endregion
                    #region set the order product 
                    if (orderData.OrderItems?.Count > 0)
                    {
                        foreach (var OrderItem in orderData.OrderItems)
                        {
                            Products products = await unitOfWork.Products.GetProduct(userId, OrderItem.ProductId);
                            if (products != null)
                            {
                                ProductsVariants productsVariants = null;
                                if (OrderItem.VariantId > 0)
                                    productsVariants = await unitOfWork.ProductVariants.GetByIdAsync(OrderItem.VariantId);
                                OrdersProducts orderProduct = new OrdersProducts();
                                orderProduct.order_id = orderId;
                                orderProduct.product_id = OrderItem.ProductId;
                                orderProduct.variant_name = productsVariants?.variant_name;
                                orderProduct.product_name = products.product_name;
                                orderProduct.varient_id = OrderItem.VariantId;
                                orderProduct.unit_price = products.base_price;
                                orderProduct.quantity = OrderItem.Quantity;
                                orderProduct.shipment_id = 0;
                                orderProduct.created_by = userId;
                                orderProduct.created_on = updated;
                                lstProducts.Add(orderProduct);
                            }
                        }
                    }
                    else
                    {
                        throw new Exception("product and varient not exist.");
                    }
                    orderId = await unitOfWork.Orders.UpdateOrderDetailDataAsync(orderDetail, BillingAddess, DeliveryAddess, lstProducts, recipients, recipientsAddresses);
                    #endregion
                }
                else
                {
                    response.StatusCode = HttpStatusCode.BadRequest;
                    response.Message = "Bad Request";
                    return response;
                }
            }
            catch (Exception ex)
            {
                if (orderId > 0)
                    await unitOfWork.Orders.UpdateOrderActiveFlag(orderId, false);
                response.StatusCode = HttpStatusCode.InternalServerError;
                response.Message = ex.Message;
            }
            response.StatusCode = HttpStatusCode.OK;
            response.Message = "Success";
            return response;
        }

      

    }
}
