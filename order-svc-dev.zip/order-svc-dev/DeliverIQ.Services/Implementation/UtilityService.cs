﻿using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.Repositories.Interface;
using DeliverIQ.Services.Interface;
using DeliverIQ.Services.Model.Request;
using DeliverIQ.Utilities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using DeliverIQ.Services.Model.Response;

namespace DeliverIQ.Services.Implementation
{
    public class UtilityService : IUtilityService
    {
        private readonly IUnitOfWork unitOfWork;
        public UtilityService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public async Task<IReadOnlyList<Countries>> GetAllCountries()
        {
            var data = await unitOfWork.Countries.GetAllCountries();
            return data;
        }

        public async Task<List<CountryStates>> GetStatesByCountryId(long countryId)
        {
            var states = await unitOfWork.States.GetStatesByCountryId(countryId);

            List<CountryStates> stateList = new List<CountryStates>();

            foreach (var item in states)
            {
                CountryStates state = new CountryStates();
                state.Id = item.id;
                state.Name = item.name;
                state.Code = item.code;
                state.CountryId = item.country_id;

                stateList.Add(state);
            }

            return stateList;
        }

        public async Task<IReadOnlyList<OrderShippingMethod>> GetShippingMethods()
        {
            return (from ShippingMethods ship in Enum.GetValues(typeof(ShippingMethods))
                    select new OrderShippingMethod
                    {
                        id = ((int)ship),
                        name = ship.ToDescription(),
                    }).ToList();
        }

        public OrderShippingPrice GetShippingPrice(long shippingMethodId)
        {
            return new OrderShippingPrice { id = shippingMethodId, price = 10 };
        }

        public async Task<IReadOnlyList<OrderPaymentType>> GetPaymentTypes()
        {
            return (from PaymentTypes pay in Enum.GetValues(typeof(PaymentTypes))
                    select new OrderPaymentType
                    {
                        id = ((int)pay),
                        name = pay.ToDescription(),
                    }).ToList();
        }

        public async Task<IReadOnlyList<RecipientTitle>> GetTitleMaster()
        {
            return (from TitleMaster title in Enum.GetValues(typeof(TitleMaster))
                    select new RecipientTitle
                    {
                        id = (int)title,
                        name = title.ToDescription(),
                    }).ToList();
        }

        public async Task<IReadOnlyList<OrderWorkflow>> GetOrderStatus()
        {
            return (from OrderStatus status in Enum.GetValues(typeof(OrderStatus))
                    select new OrderWorkflow
                    {
                        id = (int)status,
                        name = status.ToDescription(),
                    }).ToList();
        }


        public async Task<IReadOnlyList<Marketplace>> GetMarketplaces(long? userId)
        {
            var marketplaces = await unitOfWork.Marketplaces.GetMarketplacesByUserId(userId);

            List<Marketplace> data = new List<Marketplace>();

            Marketplace place;

            foreach (var item in marketplaces)
            {
                place = new Marketplace();
                place.id = item.id;
                place.name = item.name;

                data.Add(place);
            }

            return data;
        }
    }
}
