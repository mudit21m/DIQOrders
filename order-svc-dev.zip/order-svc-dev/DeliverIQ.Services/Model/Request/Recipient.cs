﻿using DeliverIQ.Utilities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.Services.Model.Request
{
    public class Recipient
    {
        public int userId { get; set; }


        public int recipientId { get; set; }

    }
}
