﻿using DeliverIQ.Utilities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.Services.Model.Request
{
    public class CreateEditProduct
    {
        //[JsonProperty("contactDetails")]
        //public CreateEditOrderContactDetails ContactDetails { get; set; }

        //[JsonProperty("address")]
        //public CreateEditOrderAddress Address { get; set; }

        //[JsonProperty("GPRDConsent")]
        //public CreateEditOrderGprdConsent GprdConsent { get; set; }

        //[JsonProperty("OrderItems")]
        //public List<CreateEditOrderOrderItem> OrderItems { get; set; }

        //[JsonProperty("shippingDetails")]
        //public CreateEditOrderShippingDetails ShippingDetails { get; set; }

        //[JsonProperty("paymentMode")]
        //public long PaymentMode { get; set; }
    }

    public class CreateEditProductVariant
    {
        //[JsonProperty("useAsSameForBilling")]
        //public bool UseAsSameForBilling { get; set; }

        //[JsonProperty("deliveryAddress")]
        //public CreateEditOrderBillingAddressClass DeliveryAddress { get; set; }

        //[JsonProperty("billingAddress")]
        //public CreateEditOrderBillingAddressClass BillingAddress { get; set; }
    }

    public class Product
    {
        public int userId { get; set; }


        public int productId { get; set; }

    }

}
