﻿using DeliverIQ.Utilities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DeliverIQ.Services.Model.Request
{
    public class CreateOrder
    {
        public CreateOrder()
        {
            ContactDetails = new CreateOrderContactDetails();
            Address = new CreateOrderAddress();
            OrderItems = new List<CreateOrderOrderItem>();
            ShippingDetails = new CreateOrderShippingDetails();
        }
        [JsonProperty("orderId", NullValueHandling = NullValueHandling.Ignore)]
        public long? OrderId { get; set; }
        [JsonProperty("contactDetails")]
        public CreateOrderContactDetails ContactDetails { get; set; }

        [JsonProperty("address")]
        public CreateOrderAddress Address { get; set; }


        [JsonProperty("orderItems")]
        public List<CreateOrderOrderItem> OrderItems { get; set; }

        [JsonProperty("shippingDetails")]
        public CreateOrderShippingDetails ShippingDetails { get; set; }

        [Required]
        [JsonProperty("paymentType")]
        public PaymentTypes PaymentType { get; set; }

        [Required]
        [JsonProperty("subTotal")]
        public decimal SubTotal { get; set; }

        [Required]
        [JsonProperty("taxTotal")]
        public decimal TaxTotal { get; set; }

        [Required]
        [JsonProperty("shippingMethodTotal")]
        public decimal ShippingMethodTotal { get; set; }

        [Required]
        [JsonProperty("total")]
        public decimal Total { get; set; }

        [Required]
        [JsonProperty("discountTotal")]
        public decimal DiscountTotal { get; set; }
    }

    public class CreateOrderAddress
    {
        public CreateOrderAddress()
        {
            DeliveryAddress = new CreateOrderBillingAddressClass();
            BillingAddress = new CreateOrderBillingAddressClass();
        }
        [JsonProperty("useAsSameForBilling")]
        public bool UseAsSameForBilling { get; set; }

        [JsonProperty("deliveryAddress")]
        public CreateOrderBillingAddressClass DeliveryAddress { get; set; }

        [JsonProperty("billingAddress")]
        public CreateOrderBillingAddressClass BillingAddress { get; set; }
    }

    public class CreateOrderBillingAddressClass
    {
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public long? Id { get; set; }
        [Required]
        [JsonProperty("isResidential")]
        public bool IsResidential { get; set; }

        [Required]
        [JsonProperty("countryId")]
        public long CountryId { get; set; }

        [Required]
        [JsonProperty("stateId")]
        public long StateId { get; set; }

        [Required]
        [JsonProperty("address1")]
        public string Address1 { get; set; }

        [JsonProperty("address2")]
        public string Address2 { get; set; }

        [JsonProperty("address3")]
        public string Address3 { get; set; }

        [Required]
        [JsonProperty("city")]
        public string City { get; set; }

        [Required]
        [JsonProperty("postalCode")]
        public string PostalCode { get; set; }
    }

    public class CreateOrderContactDetails
    {
        [Required]
        [JsonProperty("title")]
        public TitleMaster Title { get; set; }

        [Required]
        [JsonProperty("name")]
        public string Name { get; set; }

        [Required]
        [JsonProperty("surName")]
        public string SurName { get; set; }

        [Required]
        [JsonProperty("email")]
        public string Email { get; set; }

        [Required]
        [JsonProperty("phone")]
        public string Phone { get; set; }
    }

    public class CreateOrderOrderItem
    {
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public long? Id { get; set; }
        [Required]
        [JsonProperty("productId")]
        public long ProductId { get; set; }

        [Required]
        [JsonProperty("variantId")]
        public long VariantId { get; set; }

        [Required]
        [JsonProperty("quantity")]
        public long Quantity { get; set; }
    }

    public class CreateOrderShippingDetails
    {
        [JsonProperty("shippingId")]
        public long ShippingId { get; set; }

        [JsonProperty("expectedDeliveryDate")]
        public string ExpectedDeliveryDate { get; set; }

        [JsonProperty("notes")]
        public string Notes { get; set; }
    }
}
