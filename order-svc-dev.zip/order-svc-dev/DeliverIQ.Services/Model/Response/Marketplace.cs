﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.Services.Model.Response
{
    public class Marketplace
    {
        public long id { get; set; }

        public string name { get; set; }

    }
}
