﻿using DeliverIQ.Utilities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DeliverIQ.Services.Model.Response
{
    public class RecipientDetails
    {
        public RecipientDetails()
        {
            Address = new RecipientAddressClass();
        }

        [JsonProperty("recipientId")]
        public long RecipientId { get; set; }

        [JsonProperty("title")]
        public long Title { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("surname")]
        public string SurName { get; set; }

        [JsonProperty("emailId")]
        public string EmailId { get; set; }

        [JsonProperty("phoneNumber")]
        public string PhoneNumber { get; set; }

        [JsonProperty("address")]
        public RecipientAddressClass Address { get; set; }
    }

    public class RecipientAddressClass
    {
        [JsonProperty("id")]
        public long Id{ get; set; }

        [JsonProperty("billingIsResidential")]
        public bool BillingIsResidential { get; set; }

        [JsonProperty("billingCountryId")]
        public long BillingCountryId { get; set; }

        [JsonProperty("billingStateId")]
        public long BillingStateId { get; set; }

        [JsonProperty("billingAddress1")]
        public string BillingAddress1 { get; set; }

        [JsonProperty("billingAddress2")]
        public string BillingAddress2 { get; set; }

        [JsonProperty("billingAddress3")]
        public string BillingAddress3 { get; set; }

        [JsonProperty("billingCity")]
        public string BillingCity { get; set; }

        [JsonProperty("billingPostalCode")]
        public string BillingPostalCode { get; set; }

        [JsonProperty("deliveryIsResidential")]
        public bool DeliveryIsResidential { get; set; }

        [JsonProperty("deliveryCountryId")]
        public long DeliveryCountryId { get; set; }

        [JsonProperty("deliveryStateId")]
        public long DeliveryStateId { get; set; }

        [JsonProperty("deliveryAddress1")]
        public string DeliveryAddress1 { get; set; }

        [JsonProperty("deliveryAddress2")]
        public string DeliveryAddress2 { get; set; }

        [JsonProperty("deliveryAddress3")]
        public string DeliveryAddress3 { get; set; }

        [JsonProperty("deliveryCity")]
        public string DeliveryCity { get; set; }

        [JsonProperty("deliveryPostalCode")]
        public string DeliveryPostalCode { get; set; }
    }

    public class RecipientTitle
    {
        [JsonProperty("id")]
        public long id { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }

    }
}