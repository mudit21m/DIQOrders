﻿using DeliverIQ.Utilities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.Services.Model.Response
{
    public class RecipientDetail
    {
        public RecipientDetail()
        {
            RecipientAddresses = new List<RecipientAddressDetail>();
        }
        [JsonProperty("userId")]
        public long UserId { get; set; }

        [JsonProperty("recipientId")]
        public long RecipientId { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("surname")]
        public string SurName { get; set; }

        [JsonProperty("title")]
        public long Title { get; set; }

        [JsonProperty("emailId")]
        public string EmailId { get; set; }

        [JsonProperty("phoneNumber")]
        public string PhoneNumber { get; set; }

        [JsonProperty("recipientAddresses")]
        public List<RecipientAddressDetail> RecipientAddresses { get; set; }

    }

    public class RecipientAddressDetail
    {
        [JsonProperty("Id")]
        public long AddressId { get; set; }

        [JsonProperty("deliveryAddress1")]
        public string DeliveryAddress1 { get; set; }

        [JsonProperty("deliveryAddress2")]
        public string DeliveryAddress2 { get; set; }

        [JsonProperty("deliveryAddress3")]
        public string DeliveryAddress3 { get; set; }

        [JsonProperty("deliveryCity")]
        public string DeliveryCity { get; set; }

        [JsonProperty("deliveryStateId")]
        public long DeliveryStateId { get; set; }

        [JsonProperty("deliveryPostalCode")]
        public string DeliveryPostalCode { get; set; }

        [JsonProperty("deliveryCountryId")]
        public long DeliveryCountryId { get; set; }

        [JsonProperty("deliveryIsResidential")]
        public bool DeliveryIsResidential { get; set; }

        [JsonProperty("billingAddress1")]
        public string BillingAddress1 { get; set; }

        [JsonProperty("billingAddress2")]
        public string BillingAddress2 { get; set; }

        [JsonProperty("billingAddress3")]
        public string BillingAddress3 { get; set; }

        [JsonProperty("billingCity")]
        public string BillingCity { get; set; }

        [JsonProperty("billingStateId")]
        public long BillingStateId { get; set; }

        [JsonProperty("billingPostalCode")]
        public string BillingPostalCode { get; set; }

        [JsonProperty("billingCountryId")]
        public long BillingCountryId { get; set; }

        [JsonProperty("billingIsResidential")]
        public bool BillingIsResidential { get; set; }




    }
}
