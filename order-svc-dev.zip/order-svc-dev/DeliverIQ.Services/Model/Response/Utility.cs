﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.Services.Model.Response
{
    public class Utility
    {
        

    }

    public class OrderWorkflow
    {
        [JsonProperty("id")]
        public long id { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }

    }

    public class OrderActions
    {
        [JsonProperty("id")]
        public long id { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }

    }
}
