﻿using DeliverIQ.Utilities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.Services.Model.Response
{
    public class ProductDetail
    {
        public ProductDetail()
        {
            ProductPhotos = new List<ProductPhoto>();
            ProductVariants = new List<ProductVariant>();
            ProductPackages = new List<ProductPackage>();
        }

        [JsonProperty("productId")]
        public long ProductId { get; set; }

        [JsonProperty("productName")]
        public string ProductName { get; set; }

        //[JsonProperty("userId")]
        //public long UserId { get; set; }

        [JsonProperty("diqProductCode")]
        public string DiqProductCode { get; set; }

        [JsonProperty("basePrice")]
        public decimal BasePrice { get; set; }

        [JsonProperty("currencyId")]
        public long CurrencyId { get; set; }

        [JsonProperty("productDescription")]
        public string ProductDescription { get; set; }

        [JsonProperty("productFiscalGroupId")]
        public long ProductFiscalGroupId { get; set; }

        [JsonProperty("barcodeTypeId")]
        public long BarcodeTypeId { get; set; }

        [JsonProperty("barcode")]
        public string Barcode { get; set; }

        [JsonProperty("hasVariant")]
        public bool HasVariant { get; set; }

        [JsonProperty("productTax")]
        public decimal ProductTax { get; set; }

        [JsonProperty("productStatus")]
        public long ProductStatus { get; set; }

        [JsonProperty("productPhotos")]
        public List<ProductPhoto> ProductPhotos { get; set; }

        [JsonProperty("productVariants")]
        public List<ProductVariant> ProductVariants { get; set; }

        [JsonProperty("productPackages")]
        public List<ProductPackage> ProductPackages { get; set; }
    }

    public class ProductPhoto
    {
        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("productId")]
        public long ProductId { get; set; }

        [JsonProperty("imageUrl")]
        public string ImageUrl { get; set; }

        [JsonProperty("variantId")]
        public long VariantId { get; set; }

    }

    public class ProductVariant
    {
        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("productId")]
        public long ProductId { get; set; }

        [JsonProperty("variantName")]
        public string VariantName { get; set; }

        [JsonProperty("additionalDescription")]
        public string AdditionalDescription { get; set; }

        [JsonProperty("isSeprateBarcode")]
        public bool IsSeprateBarcode { get; set; }

        [JsonProperty("barcodeTypeId")]
        public long BarcodeTypeId { get; set; }

        [JsonProperty("barcode")]
        public string Barcode { get; set; }
    }

    public class ProductPackage
    {
        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("variantId")]
        public long VariantId { get; set; }

        [JsonProperty("width")]
        public decimal Width { get; set; }

        [JsonProperty("height")]
        public decimal Height { get; set; }

        [JsonProperty("length")]
        public decimal Length { get; set; }

        [JsonProperty("weight")]
        public decimal Weight { get; set; }

        [JsonProperty("dimUnit")]
        public long DimUnit { get; set; }

        [JsonProperty("weightUnit")]
        public long WeightUnit { get; set; }
    }

}
