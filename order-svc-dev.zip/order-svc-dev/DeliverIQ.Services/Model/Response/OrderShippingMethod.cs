﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.Services.Model.Response
{
    public class OrderShippingMethod
    {
        [JsonProperty("id")]
        public long id { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }
    }

    public class OrderShippingPrice
    {
        [JsonProperty("id")]
        public long id { get; set; }

        [JsonProperty("price")]
        public decimal price { get; set; }
    }
}
