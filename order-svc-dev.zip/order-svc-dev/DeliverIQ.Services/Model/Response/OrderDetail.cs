﻿using DeliverIQ.Utilities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DeliverIQ.Services.Model.Response
{
    public class OrderDetail
    {
        public OrderDetail()
        {
            ContactDetails = new OrderContactDetails();
            Address = new OrderAddress();
            OrderItems = new List<OrderItem>();
            ShippingDetails = new OrderShippingDetails();
        }
        [JsonProperty("contactDetails")]
        public OrderContactDetails ContactDetails { get; set; }

        [JsonProperty("address")]
        public OrderAddress Address { get; set; }

        [JsonProperty("orderItems")]
        public List<OrderItem> OrderItems { get; set; }

        [JsonProperty("shippingDetails")]
        public OrderShippingDetails ShippingDetails { get; set; }
        
        [JsonProperty("paymentMode")]
        public long PaymentMode { get; set; }

        [JsonProperty("orderId")]
        public long OrderId { get; set; }

        [JsonProperty("customerMarketplaceId")]
        public long? customerMarketplaceId { get; set; }

        [JsonProperty("DIQOrderNnumber")]
        public string DIQOrderNnumber { get; set; }

        [JsonProperty("marketplaceOrderNumber")]
        public string MarketplaceOrderNumber { get; set; }

        [JsonProperty("marketplaceOrderId")]
        public string MarketplaceOrderId { get; set; }

        [JsonProperty("orderDate")]
        public DateTime OrderDate { get; set; }

        [JsonProperty("orderCreatedDate")]
        public DateTime OrderCreatedDate { get; set; }

        [JsonProperty("orderModifiedDate")]
        public DateTime OrderModifiedDate { get; set; }

        [JsonProperty("shipByDate")]
        public DateTime ShipByDate { get; set; }

        [JsonProperty("orderStatusId")]
        public OrderStatus OrderStatusId { get; set; }

        [JsonProperty("isFulfilled")]
        public bool IsFulfilled { get; set; }

        [JsonProperty("orderModificationStatus")]
        public long OrderModificationStatus { get; set; }

        [JsonProperty("shippingTypeMode")]
        public long? ShippingTypeMode { get; set; }

        [JsonProperty("shipTransitTime")]
        public string ShipTransitTime { get; set; }

        [JsonProperty("orderDiscount")]
        public decimal? OrderDiscount { get; set; }

        [JsonProperty("orderDiscountType")]
        public string OrderDiscountType { get; set; }

        [JsonProperty("orderMiscCharges")]
        public decimal OrderMiscCharges { get; set; }

        [JsonProperty("orderCarrier")]
        public string OrderCarrier { get; set; }

        [JsonProperty("orderShippingNotes")]
        public string OrderShippingNotes { get; set; }

        [JsonProperty("paymentType")]
        public PaymentTypes PaymentType { get; set; }

        [JsonProperty("userId")]
        public long? UserId { get; set; }

        [JsonProperty("subTotal")]
        public decimal SubTotal { get; set; }

        [JsonProperty("taxTotal")]
        public decimal TaxTotal { get; set; }

        [JsonProperty("shippingTotal")]
        public decimal ShippingTotal { get; set; }

        [JsonProperty("orderTotal")]
        public decimal OrderTotal { get; set; }
    }

    public class OrderAddress
    {
        public OrderAddress()
        {
            DeliveryAddress = new OrderAddressClass();
            BillingAddress = new OrderAddressClass();
        }
        
        [JsonProperty("useAsSameForBilling")]
        public bool UseAsSameForBilling { get; set; }

        [JsonProperty("deliveryAddress")]
        public OrderAddressClass DeliveryAddress { get; set; }

        [JsonProperty("billingAddress")]
        public OrderAddressClass BillingAddress { get; set; }
    }

    public class OrderAddressClass
    {
        [JsonProperty("id")]
        public long Id{ get; set; }

        [JsonProperty("isResidential")]
        public bool IsResidential { get; set; }

        [JsonProperty("countryId")]
        public long CountryId { get; set; }

        [JsonProperty("stateId")]
        public long StateId { get; set; }

        [JsonProperty("address1")]
        public string Address1 { get; set; }

        [JsonProperty("address2")]
        public string Address2 { get; set; }

        [JsonProperty("address3")]
        public string Address3 { get; set; }

        [JsonProperty("city")]
        public string City { get; set; }

        [JsonProperty("postalCode")]
        public string PostalCode { get; set; }
        
    }

    public class OrderContactDetails
    {

        [JsonProperty("title")]
        public long Title { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("surName")]
        public string SurName { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("phone")]
        public string Phone { get; set; }
    }

  

    public class OrderItem
    {

        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("productId")]
        public long ProductId { get; set; }

        [JsonProperty("variantId")]
        public long VariantId { get; set; }

        [JsonProperty("quantity")]
        public long Quantity { get; set; }
    }

    public class OrderShippingDetails
    {
        [JsonProperty("shippingId")]
        public long ShippingId { get; set; }

        [JsonProperty("expectedDeliveryDate")]
        public string ExpectedDeliveryDate { get; set; }

        [JsonProperty("notes")]
        public string Notes { get; set; }
    }

    public class OrdersData
    {
        [JsonProperty("orderId")]
        public long OrderId { get; set; }
       
        [JsonProperty("DIQOrderNumber")]
        public string DIQOrderNumber { get; set; }
        
        [JsonProperty("orderDate")]
        public DateTime OrderDate { get; set; }
        
        [JsonProperty("orderStatus")]
        public string OrderStatus { get; set; }

        [JsonProperty("orderStatusId")]
        public long OrderStatusId { get; set; }

        [JsonProperty("orderTotal")]
        public decimal OrderTotal { get; set; }
       
        [JsonProperty("recipientName")]
        public string RecipientName { get; set; }
       
        //[JsonProperty("phoneNo")]
        //public string Phoneno { get; set; }
      
        //[JsonProperty("emailId")]
        //public string EmailId { get; set; }
       
        [JsonProperty("marketPlaceId")]
        public int MarketPlaceId { get; set; }

        [JsonProperty("marketPlaceName")]
        public string MarketPlaceName { get; set; }

        [JsonProperty("sourceId")]
        public string SourceId { get; set; }

        [JsonProperty("countryName")]
        public string CountryName { get; set; }

        [JsonProperty("postalCode")]
        public string PostalCode { get; set; }

    }
}
