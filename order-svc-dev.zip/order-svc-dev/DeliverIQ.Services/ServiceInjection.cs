﻿using DeliverIQ.Repositories;
using DeliverIQ.Services.Implementation;
using DeliverIQ.Services.Interface;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.Services
{
    public static class ServiceInjection
    {
        public static IServiceCollection RegisterServices(this IServiceCollection services)
        {
            services.AddScoped<IOrderService, OrderService>();
            services.AddScoped<IUtilityService, UtilityService>();
            services.AddScoped<IRecipientService, RecipientService>();
            services.AddScoped<IProductService, ProductService>();
            services.RegisterRepositories();
            return services;
        }
    }
}
