﻿using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.Services.Model.Response;
using DeliverIQ.Services.Model.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Services.Interface
{
    public interface IRecipientService
    {
        Task<IReadOnlyList<RecipientDetails>> GetAllRecipients(long userId);

        Task<RecipientDetail> GetRecipientDetail(long userId, long recipientId);

        Task<RecipientDetail> GetRecipientDetail(long userId, string email);

    }
}
