﻿using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.Services.Model.Response;
using DeliverIQ.Services.Model.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Services.Interface
{
    public interface IUtilityService
    {
        Task<IReadOnlyList<Countries>> GetAllCountries();

        Task<List<CountryStates>> GetStatesByCountryId(long countryId);

        Task<IReadOnlyList<OrderShippingMethod>> GetShippingMethods();

        Task<IReadOnlyList<OrderPaymentType>> GetPaymentTypes();

        OrderShippingPrice GetShippingPrice(long shippingMethodId);

        Task<IReadOnlyList<RecipientTitle>> GetTitleMaster();

        Task<IReadOnlyList<OrderWorkflow>> GetOrderStatus();

        Task<IReadOnlyList<Marketplace>> GetMarketplaces(long? userId);
    }
}
