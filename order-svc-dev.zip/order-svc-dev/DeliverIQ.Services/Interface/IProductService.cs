﻿using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.Services.Model.Response;
using DeliverIQ.Services.Model.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Services.Interface
{
    public interface IProductService
    {
        Task<List<ProductDetail>> GetAllProducts(long userId);
        Task<ProductDetail> GetProductDetail(long userId, long productId);

        Task<int> Add(CreateEditProduct product);

        Task<IReadOnlyList<ProductsFiscalGroups>> GetProductsFiscalGroups(long userId);

        Task<List<ProductDetail>> GetProductsByUserId(long userId);


    }
}
