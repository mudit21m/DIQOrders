﻿using DeliverIQ.DataAccess.Data.Model;
using DeliverIQ.DataAccess.Data.Model.Request;
using DeliverIQ.Services.Model.Request;
using DeliverIQ.Services.Model.Response;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DeliverIQ.Services.Interface
{
    public interface IOrderService
    {
        Task<BaseResponse<List<OrdersData>>> GetOrdersByUserId(long userId, OrderFilter orderFilter);
        Task<Orders> GetById(int id);
        Task<BaseResponse<int>> AddOrder(CreateOrder order, long userId);

        //Task<IReadOnlyList<OrdersAddresses>> GetCustomers(int userid);
        //Task<int> Delete(int id);
        Task<BaseResponse<int>> Update(CreateOrder orderData, long userId);
        Task<CreateOrder> GetOrderDetailsById(int id);
    }
}
