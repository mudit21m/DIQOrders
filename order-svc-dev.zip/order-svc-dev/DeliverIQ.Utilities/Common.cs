﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DeliverIQ.Utilities
{
    public class Common
    {
        private static Random random = new Random();
        public static string GenerateOrderNumber(long userId)
        {
            var timeSpan = (DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0));
            long ephocTime = (long)timeSpan.TotalSeconds;
            string orderNumber = "ORD-" + Convert.ToString(userId) + "-" + Convert.ToString(ephocTime);
            return orderNumber;
        }
    }
}
