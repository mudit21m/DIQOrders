﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace DeliverIQ.Utilities
{
    public enum CarrierType
    {
        DHL = 1,
        TNT = 2,
        UPS = 3
    }

    public enum MarketPlaceType
    {
        Etsy = 1,
        Volusion = 2
    }

    public enum CarrierOperation
    {
        CancelDispatch = 1,
        CancelShipment = 2,
        Rate = 3,
        Shipment = 4,
        TrackShipment = 5,
        TransitTime = 6,
        Tariff = 7,
        AbstractInvoice = 8,
        Dispatch = 9,
        ParcelShop = 10,

    }
    public enum DatabaseConnection
    {
        PostgresConnection,
        MSSQLConnection
    }

    public enum ShippingMethods
    {
        [Display(Name = "Standard")]
        [Description("Standard")]
        Standard = 1,

        [Display(Name = "Express")]
        [Description("Express")]
        Express = 2
    }

    public enum PaymentTypes
    {
        [Display(Name = "Prepaid")]
        [Description("Prepaid")]
        Prepaid = 1,

        [Display(Name = "Cash on delivery")]
        [Description("Cash on delivery")]
        CashOnDelivery = 2
    }
    public enum AddressType
    {
        Billing = 1,
        Delivery = 2
    }

    public enum OrderStatus
    {
        [Display(Name = "Unapproved")]
        [Description("Unapproved")]
        Unapproved = 1,

        [Display(Name = "Approved")]
        [Description("Approved")]
        Approved = 2,

        [Display(Name = "Partially allocated")]
        [Description("Partially allocated")]
        PartiallyAllocated = 3,

        [Display(Name = "Allocated")]
        [Description("Allocated")]
        Allocated = 4,

        [Display(Name = "Picking")]
        [Description("Picking")]
        Picking = 5,

        [Display(Name = "Picked")]
        [Description("Picked")]
        PickConfirmed = 6,

        [Display(Name = "Packed")]
        [Description("Packed")]
        Packed = 7,

        [Display(Name = "Ready to Ship")]
        [Description("Ready to Ship")]
        ReadyToShip = 8,

        [Display(Name = "Shipped")]
        [Description("Shipped")]
        Shipped = 9,

        [Display(Name = "Cancelled")]
        [Description("Cancelled")]
        Cancelled = 10,

        [Display(Name = "Held")]
        [Description("Held")]
        Held = 11
    }

    //public enum OrderStatus
    //{
    //    [Display(Name = "In progress")]
    //    [Description("In progress")]
    //    InProgress = 1,

    //    [Display(Name = "Shipped")]
    //    [Description("Shipped")]
    //    Shipped = 2,

    //    [Display(Name = "Fulfilled")]
    //    [Description("Fulfilled")]
    //    Fulfilled = 3,

    //    [Display(Name = "Canceled")]
    //    [Description("Canceled")]
    //    Canceled = 4,

    //    [Display(Name = "Partially missing inventory")]
    //    [Description("Partially missing inventory")]
    //    PartiallyMissingInventory = 5,

    //    [Display(Name = "Needs attention")]
    //    [Description("Needs attention")]
    //    NeedsAttention = 6,
    //}

    public enum TitleMaster
    {
        [Display(Name = "Mr")]
        [Description("Mr")]
        Mr = 1,

        [Display(Name = "Mrs")]
        [Description("Mrs")]
        Mrs = 2,

        [Display(Name = "Miss")]
        [Description("Miss")]
        Miss = 3,
    }

    public enum UserMarketplaces
    {
        [Display(Name = "amazon")]
        [Description("amazon")]
        Amazon = 1,

        [Display(Name = "ebay")]
        [Description("ebay")]
        Ebay,

        [Display(Name = "Big Commerce")]
        [Description("Big Commerce")]
        BigCommerce,

        [Display(Name = "Etsy")]
        [Description("Etsy")]
        Etsy,

        [Display(Name = "Linnworks")]
        [Description("Linnworks")]
        Linnworks,

        [Display(Name = "Opencart")]
        [Description("Opencart")]
        Opencart,

        [Display(Name = "shopify")]
        [Description("shopify")]
        Shopify,

        [Display(Name = "squarespace")]
        [Description("squarespace")]
        Squarespace,

        [Display(Name = "Volusion")]
        [Description("Volusion")]
        Volusion,

        [Display(Name = "Woo Commerce")]
        [Description("Woo Commerce")]
        WooCommerce,
    }
}
