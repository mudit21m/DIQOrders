﻿using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.Utilities
{
    public static class StreamExtensions
    {
        #region Private Helpers

        /// <summary>Redefined here because this is also used in the Zipper project, 
        /// which can't use FileUtils, or any other code that calls ex.Log().</summary>
        private static string FormatBytes(long bytes)
        {
            const long KiloByte = 1024L;
            const long MegaByte = KiloByte * KiloByte;
            const long GigaByte = MegaByte * KiloByte;
            const long TeraByte = GigaByte * KiloByte;
            const long PetaByte = TeraByte * KiloByte;
            const long ExaByte = PetaByte * KiloByte;

            var formattedBytes = string.Empty;

            if (bytes < KiloByte)
                formattedBytes = string.Format("{0:F2} bytes", bytes);
            else if (bytes >= KiloByte && bytes < MegaByte)
                formattedBytes = string.Format("{0:F2} KB", Math.Round((double)bytes / KiloByte, 2, MidpointRounding.AwayFromZero));
            else if (bytes >= MegaByte && bytes < GigaByte)
                formattedBytes = string.Format("{0:F2} MB", Math.Round((double)bytes / MegaByte, 2, MidpointRounding.AwayFromZero));
            else if (bytes >= GigaByte && bytes < TeraByte)
                formattedBytes = string.Format("{0:F2} GB", Math.Round((double)bytes / GigaByte, 2, MidpointRounding.AwayFromZero));
            else if (bytes >= TeraByte && bytes < PetaByte)
                formattedBytes = string.Format("{0:F2} TB", Math.Round((double)bytes / TeraByte, 2, MidpointRounding.AwayFromZero));
            else if (bytes >= PetaByte && bytes < ExaByte)
                formattedBytes = string.Format("{0:F2} PB", Math.Round((double)bytes / PetaByte, 2, MidpointRounding.AwayFromZero));
            else if (bytes >= ExaByte)
                formattedBytes = string.Format("{0:F2} EB", Math.Round((double)bytes / ExaByte, 2, MidpointRounding.AwayFromZero));

            return formattedBytes;
        }

        #endregion

        #region CopyToStreamAsync

        public static Task CopyToStreamAsync(this Stream source, Stream destination)
        {
            return source.CopyToStreamAsync(destination, Constants.BufferSize);
        }

        /// <summary>An implementation to copy asynchronously from one stream to another,
        /// similar to <see cref="System.IO.Stream.CopyToAsync(Stream)"/></summary>
        /// <remarks>
        /// This was written because the default implementation would sometimes throw OutOfMemoryExceptions
        /// in my FileAsync.ReadAllBytesAsync method, when opening large Bitmap files. Reading with a fixed
        /// size small buffer works well as a general solution, though I have also begun using a larger
        /// buffer to improve performance with larger files.</remarks>
        public static async Task CopyToStreamAsync(this Stream source, Stream destination, int bufferSize)
        {
            if (source == null)
                throw new ArgumentNullException("source");

            if (destination == null)
                throw new ArgumentNullException("destination");

            if (bufferSize <= 0)
                throw new ArgumentOutOfRangeException("bufferSize", "bufferSize must be greater than zero");

            /* The source stream may not support seeking; e.g. a stream
             * returned by ZipArchiveEntry.Open() or a network stream. */
            var size = bufferSize;
            var canSeek = source.CanSeek;

            if (canSeek)
            {
                try
                {
                    size = (int)Math.Min(bufferSize, source.Length);
                }
                catch (NotSupportedException) { canSeek = false; }
            }

            var buffer = new byte[size];
            var remaining = canSeek ? source.Length : 0;

            /* If the stream is seekable, seek through it until all bytes are read.
             * If we read less than the expected number of bytes, it indicates an
             * error, so throw the appropriate exception.
             *
             * If the stream is not seekable, loop until we read 0 bytes. (It's not
             * an error in this case.) */
            while (!canSeek || remaining > 0)
            {
                var read = await source.ReadAsync(buffer, 0, size);

                if (read <= 0)
                {
                    if (canSeek)
                        throw new EndOfStreamException(
                          string.Format("End of stream reached, but {0} remained to be read.",
                          FormatBytes(remaining)));
                    else
                        break;
                }

                await destination.WriteAsync(buffer, 0, read);
                remaining -= canSeek ? read : 0;
            }
        }

        #endregion

        #region Reopen

        private const uint FILE_FLAG_OVERLAPPED = 0x40000000;

        public static FileStream Reopen(this FileStream source, FileAccess access, FileShare share, int bufferSize, bool useAsync)
        {
            var fileAccess = EFileAccess.GenericWrite;

            switch (access)
            {
                case FileAccess.Read:
                    fileAccess = EFileAccess.GenericRead;
                    break;
                case FileAccess.ReadWrite:
                    fileAccess = EFileAccess.GenericRead | EFileAccess.GenericWrite;
                    break;
                case FileAccess.Write:
                    fileAccess = EFileAccess.GenericWrite;
                    break;
            }

            var fileShare = EFileShare.Read | EFileShare.Write;

            switch (share)
            {
                case FileShare.Delete:
                    fileShare = EFileShare.Delete;
                    break;
                case FileShare.Inheritable:
                    fileShare = source.CanRead ? EFileShare.Read : source.CanWrite ? EFileShare.Write : EFileShare.None;
                    break;
                case FileShare.None:
                    fileShare = EFileShare.None;
                    break;
                case FileShare.Read:
                    fileShare = EFileShare.Read;
                    break;
                case FileShare.ReadWrite:
                    fileShare = EFileShare.Read | EFileShare.Write;
                    break;
                case FileShare.Write:
                    fileShare = EFileShare.Write;
                    break;
            }

            return new FileStream(NativeMethods.ReOpenFile(source.SafeFileHandle, (uint)fileAccess, (uint)fileShare, useAsync ? FILE_FLAG_OVERLAPPED : 0), access, bufferSize, useAsync);
        }

        #region Interop

        private static class NativeMethods
        {
            [DllImport("kernel32", SetLastError = true)]
            public static extern SafeFileHandle ReOpenFile(SafeFileHandle hOriginalFile, uint dwAccess, uint dwShareMode, uint dwFlags);
        }

        [Flags]
        private enum EFileAccess : uint
        {
            // Standard Section
            AccessSystemSecurity = 0x1000000,   // AccessSystemAcl access type
            MaximumAllowed = 0x2000000,     // MaximumAllowed access type

            Delete = 0x10000,
            ReadControl = 0x20000,
            WriteDAC = 0x40000,
            WriteOwner = 0x80000,
            Synchronize = 0x100000,

            StandardRightsRequired = 0xF0000,
            StandardRightsRead = ReadControl,
            StandardRightsWrite = ReadControl,
            StandardRightsExecute = ReadControl,
            StandardRightsAll = 0x1F0000,
            SpecificRightsAll = 0xFFFF,

            FILE_READ_DATA = 0x0001,        // file & pipe
            FILE_LIST_DIRECTORY = 0x0001,       // directory
            FILE_WRITE_DATA = 0x0002,       // file & pipe
            FILE_ADD_FILE = 0x0002,         // directory
            FILE_APPEND_DATA = 0x0004,      // file
            FILE_ADD_SUBDIRECTORY = 0x0004,     // directory
            FILE_CREATE_PIPE_INSTANCE = 0x0004, // named pipe
            FILE_READ_EA = 0x0008,          // file & directory
            FILE_WRITE_EA = 0x0010,         // file & directory
            FILE_EXECUTE = 0x0020,          // file
            FILE_TRAVERSE = 0x0020,         // directory
            FILE_DELETE_CHILD = 0x0040,     // directory
            FILE_READ_ATTRIBUTES = 0x0080,      // all
            FILE_WRITE_ATTRIBUTES = 0x0100,     // all

            // Generic Section
            GenericRead = 0x80000000,
            GenericWrite = 0x40000000,
            GenericExecute = 0x20000000,
            GenericAll = 0x10000000,

            SPECIFIC_RIGHTS_ALL = 0x00FFFF,
            FILE_ALL_ACCESS =
            StandardRightsRequired |
            Synchronize |
            0x1FF,

            FILE_GENERIC_READ =
            StandardRightsRead |
            FILE_READ_DATA |
            FILE_READ_ATTRIBUTES |
            FILE_READ_EA |
            Synchronize,

            FILE_GENERIC_WRITE =
            StandardRightsWrite |
            FILE_WRITE_DATA |
            FILE_WRITE_ATTRIBUTES |
            FILE_WRITE_EA |
            FILE_APPEND_DATA |
            Synchronize,

            FILE_GENERIC_EXECUTE =
            StandardRightsExecute |
             FILE_READ_ATTRIBUTES |
             FILE_EXECUTE |
             Synchronize
        }

        [Flags]
        private enum EFileShare : uint
        {
            None = 0x00000000,

            /// <summary>
            /// Enables subsequent open operations on an object to request read access.
            /// Otherwise, other processes cannot open the object if they request read access.
            /// If this flag is not specified, but the object has been opened for read access, the function fails.
            /// </summary>
            Read = 0x00000001,

            /// <summary>
            /// Enables subsequent open operations on an object to request write access.
            /// Otherwise, other processes cannot open the object if they request write access.
            /// If this flag is not specified, but the object has been opened for write access, the function fails.
            /// </summary>
            Write = 0x00000002,

            /// <summary>
            /// Enables subsequent open operations on an object to request delete access.
            /// Otherwise, other processes cannot open the object if they request delete access.
            /// If this flag is not specified, but the object has been opened for delete access, the function fails.
            /// </summary>
            Delete = 0x00000004
        }

        #endregion

        #endregion

        public static string ToDescription(this Enum value)
        {
            var da = (DescriptionAttribute[])(value.GetType().GetField(value.ToString())).GetCustomAttributes(typeof(DescriptionAttribute), false);

            return da.Length > 0 ? da[0].Description : value.ToString();
        }
    }
}