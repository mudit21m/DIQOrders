﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.Utilities
{
    public static class Constants
    {
        public static readonly char[] DelimiterChars = new char[] { '\\', '/' };

        public const int BufferSize = 0x2000;

        public const int LargeBufferSize = BufferSize * 1024;

        //public static readonly MailAddress[] ErrorRecipients = new System.Net.Mail.MailAddress[] {
        //            new System.Net.Mail.MailAddress("amresh.singh@matellio.com", "Amresh Singh") };
    }
}
