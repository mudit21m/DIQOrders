﻿using System;

namespace DeliverIQ.SoapClients
{
    public class Class1
    {
    }
}
