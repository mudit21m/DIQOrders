﻿using DeliverIQ.RestClients.Interface;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace DeliverIQ.RestClients.Implementation
{
    public class HttpClientFactory : IHttpClientFactory1, IDisposable
    {
        private readonly ConcurrentDictionary<string, HttpClient> _httpClients;

        public HttpClientFactory()
        {
            this._httpClients = new ConcurrentDictionary<string, HttpClient>();
        }

        public HttpClient Create(string endpoint)
        {
            if (this._httpClients.TryGetValue(endpoint, out var client))
            {
                return client;
            }

            client = new HttpClient
            {
                BaseAddress = new Uri(endpoint),
            };

            this._httpClients.TryAdd(endpoint, client);

            return client;
        }

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            foreach (var httpClient in this._httpClients)
            {
                httpClient.Value.Dispose();
            }
        }
    }


}
