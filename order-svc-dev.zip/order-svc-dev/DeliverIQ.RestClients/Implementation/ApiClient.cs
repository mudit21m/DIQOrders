﻿using DeliverIQ.RestClients.Interface;
using DeliverIQ.RestClients.Model;
using DeliverIQ.Utilities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.RestClients.Implementation
{
    public class ApiClient : IApiClient
    {
        private readonly HttpClient _httpClient;

        public ApiClient(HttpClient httpClient)
        {
            this._httpClient = httpClient;
        }

        public async Task<HttpResponseMessage> GetAsync(string requestUri, Dictionary<string, string> additionalHeaders = null, params KeyValuePair<string, string>[] values)
        {
            if (requestUri == null)
                throw new ArgumentNullException("requestUri");

            AddToken();
            AddHeaders(additionalHeaders);

            using (var content = new FormUrlEncodedContent(values))
            {
                var query = await content.ReadAsStringAsync();
                var requestUriWithQuery = string.Concat(requestUri, "?", query);
                var response = await _httpClient.GetAsync(requestUriWithQuery);
                return response;
            }
        }

        public async Task<HttpResponseMessage> PostAsync<T>(string requestUri, T content, Dictionary<string, string> additionalHeaders = null)
       where T : ApiModel
        {
            if (requestUri == null)
                throw new ArgumentNullException("requestUri");

            AddToken();
            AddHeaders(additionalHeaders);
            // private const string BaseUri = "Http://localhost:28601/";
            //httpClient.BaseAddress = new Uri(BaseUri);
            _httpClient.DefaultRequestHeaders.Accept.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var response = await _httpClient.PostAsJsonAsync(requestUri, content);
            return response;
        }

        public async Task<HttpResponseMessage> PutAsync<T>(string requestUri, T content, Dictionary<string, string> additionalHeaders = null)
         where T : ApiModel
        {
            if (requestUri == null)
                throw new ArgumentNullException("requestUri");

            AddToken();
            AddHeaders(additionalHeaders);

            _httpClient.DefaultRequestHeaders.Accept.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var response =await _httpClient.PutAsJsonAsync(requestUri, content);
            return response;
        }
        
        public async Task<HttpResponseMessage> DownloadAsync(string requestUri, string fileName, Dictionary<string, string> additionalHeaders = null)
        {
            if (requestUri == null)
                throw new ArgumentNullException("requestUri");

            AddToken();
            AddHeaders(additionalHeaders);

            using (var response = await _httpClient.GetAsync(requestUri))
            {
                using (Stream contentStream = await response.Content.ReadAsStreamAsync(), savedStream = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None, Constants.LargeBufferSize, true))
                {
                    await contentStream.CopyToStreamAsync(savedStream, Constants.LargeBufferSize);
                }
                return response;
            }

        }

        public async Task<HttpResponseMessage> DownloadAsyncV1(string requestUri, string fileName, Dictionary<string, string> additionalHeaders = null, params KeyValuePair<string, string>[] values)
        {
            if (requestUri == null)
                throw new ArgumentNullException("requestUri");

            AddToken();
            AddHeaders(additionalHeaders);
            using (var content = new FormUrlEncodedContent(values))
            {
                var query = await content.ReadAsStringAsync();
                var requestUriWithQuery = string.Concat(requestUri, "&", query);

                using (var response = await _httpClient.GetAsync(requestUriWithQuery))
                {
                    using (Stream contentStream = await response.Content.ReadAsStreamAsync(), savedStream = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None, Constants.LargeBufferSize, true))
                    {
                        await contentStream.CopyToStreamAsync(savedStream, Constants.LargeBufferSize);
                        HttpResponseMessage res = new HttpResponseMessage(System.Net.HttpStatusCode.OK);
                        return res;
                    }
                }
            }
        }

        public async Task<HttpResponseMessage> DeleteAsync(string requestUri, Dictionary<string, string> additionalHeaders = null)
        {
            if (requestUri == null)
                throw new ArgumentNullException("requestUri");

            AddToken();
            AddHeaders(additionalHeaders);

            using (var response =await _httpClient.DeleteAsync(requestUri))
            {
                return response;
            }
        }
        private void AddHeaders(Dictionary<string, string> additionalHeaders)
        {
            _httpClient.DefaultRequestHeaders.Add("Accept", "application/json");

            //No additional headers to be added
            if (additionalHeaders == null)
                return;

            foreach (KeyValuePair<string, string> current in additionalHeaders)
            {
                _httpClient.DefaultRequestHeaders.Add(current.Key, current.Value);
            }
        }
        private void AddToken()
        {
            //if (_tokenContainer != null && _tokenContainer.ApiToken != null)
            //{
            //    //authorize further requests
            //    _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _tokenContainer.ApiToken.ToString());
            //}
        }

    }
}
