﻿using Newtonsoft.Json;
using DeliverIQ.RestClients.Interface;
using DeliverIQ.RestClients.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.RestClients.Implementation
{

    public class ClientBase
    {
        protected readonly IApiClient _apiClient;
        public ClientBase(IApiClient apiClient)
        {
            _apiClient = apiClient;
        }
        public async Task<TResponse> GetJsonContent<TResponse, TContentResponse>(string uri, Dictionary<string, string> additionalHeaders = null, params KeyValuePair<string, string>[] requestParameters)
          where TResponse : ApiResponse<TContentResponse>, new()
        {
            using (var apiResponse = await _apiClient.GetAsync(uri, additionalHeaders, requestParameters))
            {
                return await DecodeJsonResponse<TResponse, TContentResponse>(apiResponse);
            }
        }
        public async Task<TResponse> PostJsonContent<TResponse, TModel, TPModel>(string url, TPModel model)
          where TPModel : ApiModel
          where TResponse : ApiResponse<TModel>, new()
        {
            using (var response = await _apiClient.PostAsync(url, model))
            {
                return await DecodeJsonResponse<TResponse, TModel>(response);
            }
        }
        public async Task<TResponse> PutJsonContent<TResponse, TModel, TPModel>(string url, TPModel model)
          where TPModel : ApiModel
          where TResponse : ApiResponse<TModel>, new()
        {
            using (var response = await _apiClient.PostAsync(url, model))
            {
                return await DecodeJsonResponse<TResponse, TModel>(response);
            }
        }
        public async Task<TResponse> DownloadFileAsync<TResponse, TContentResponse>(string url, string filePath)
         where TResponse : ApiResponse<TContentResponse>, new()
        {
            using (var apiResponse = await _apiClient.DownloadAsync(url, filePath))
            {
                return await DecodeJsonResponse<TResponse, TContentResponse>(apiResponse);
            }
        }
        public async Task<TResponse> DownloadFileV1Async<TResponse, TContentResponse>(string url, string filePath, Dictionary<string, string> additionalHeaders = null, params KeyValuePair<string, string>[] requestParameters)
      where TResponse : ApiResponse<TContentResponse>, new()
        {
            using (var apiResponse = await _apiClient.DownloadAsyncV1(url, filePath, additionalHeaders, requestParameters))
            {
                return await DecodeJsonResponse<TResponse, TContentResponse>(apiResponse);
            }
        }
        public async Task<TResponse> DeleteAsync<TResponse>(string url)
          where TResponse : ApiResponse, new()
        {

            using (var response = await _apiClient.DeleteAsync(url))
            {
                var clientResponse = new TResponse
                {
                    StatusIsSuccessful = response.IsSuccessStatusCode,
                    ErrorState = response.IsSuccessStatusCode ? null : await DecodeContent<ErrorStateResponse>(response),
                    ResponseCode = response.StatusCode
                };

                return clientResponse;
            }
        }


        private async Task<TContentResponse> DecodeHeader<TContentResponse>(HttpResponseMessage response, string key)
        {
            var result = await response.Content.ReadAsStringAsync();
            var headers = response.Headers;
            IEnumerable<string> values;
            string value = string.Empty;
            if (headers.TryGetValues(key, out values))
            {
                value = values.First();
            }

            return JsonConvert.DeserializeObject<TContentResponse>(value);
        }
        private async Task<TContentResponse> DecodeContent<TContentResponse>(HttpResponseMessage response)
        {
            var result = await response.Content.ReadAsStringAsync();

            return JsonConvert.DeserializeObject<TContentResponse>(result);
        }
        private async Task<TResponse> DecodeJsonResponse<TResponse, TDecode>(HttpResponseMessage apiResponse)
          where TResponse : ApiResponse<TDecode>, new()
        {

            var response = await CreateJsonResponse<TResponse>(apiResponse);

            try
            {
                response.Data = JsonConvert.DeserializeObject<TDecode>(response.ResponseResult);
                //response.Data = Json.Decode<TDecode>(response.ResponseResult);
            }
            catch (ArgumentException argex)
            {
                response.Data = GetValue<TDecode>(response.ResponseResult);
            }
            catch (Exception ex)
            {
                //throw ex;
            }

            return response;
        }
        private T GetValue<T>(String value)
        {
            return (T)Convert.ChangeType(value, typeof(T));
        }
        private async Task<TResponse> CreateJsonResponse<TResponse>(HttpResponseMessage response) where TResponse : ApiResponse, new()
        {
            var clientResponse = new TResponse
            {
                StatusIsSuccessful = response.IsSuccessStatusCode,
                ErrorState = response.IsSuccessStatusCode ? null : await DecodeContent<ErrorStateResponse>(response),
                ResponseCode = response.StatusCode
            };
            if (response.Content != null)
            {
                clientResponse.ResponseResult = await response.Content.ReadAsStringAsync();
            }

            return clientResponse;
        }


    }

}