﻿using DeliverIQ.RestClients.Model;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.RestClients.Interface
{
    public interface IApiClient
    {
        Task<HttpResponseMessage> GetAsync(string requestUri, Dictionary<string, string> additionalHeaders = null, params KeyValuePair<string, string>[] values);
        Task<HttpResponseMessage> PostAsync<T>(string requestUri, T content, Dictionary<string, string> additionalHeaders = null) where T : ApiModel;
        Task<HttpResponseMessage> PutAsync<T>(string requestUri, T content, Dictionary<string, string> additionalHeaders = null) where T : ApiModel;
        Task<HttpResponseMessage> DownloadAsync(string requestUri, string fileName, Dictionary<string, string> additionalHeaders = null);
        Task<HttpResponseMessage> DownloadAsyncV1(string requestUri, string fileName, Dictionary<string, string> additionalHeaders = null, params KeyValuePair<string, string>[] values);
        Task<HttpResponseMessage> DeleteAsync(string requestUri, Dictionary<string, string> additionalHeaders = null);
    }
}
