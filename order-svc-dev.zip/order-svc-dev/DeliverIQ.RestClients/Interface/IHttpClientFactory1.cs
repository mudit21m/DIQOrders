﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace DeliverIQ.RestClients.Interface
{
    public interface IHttpClientFactory1
    {
        HttpClient Create(string endpoint);
    }
}
