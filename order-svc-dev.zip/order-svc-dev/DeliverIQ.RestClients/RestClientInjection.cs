﻿using Microsoft.Extensions.DependencyInjection;
using DeliverIQ.RestClients.Implementation;
using DeliverIQ.RestClients.Interface;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.RestClients
{
    public static class RestClientInjection
    {
        public static IServiceCollection RegisterRestClient(this IServiceCollection services)
        {
            //services.AddScoped<IApiClient, ApiClient>();
            //services.AddScoped<ClientBase, ClientBase>();

          //  services.AddSingleton<ClientBase>();
            return services;
        }
    }
}
