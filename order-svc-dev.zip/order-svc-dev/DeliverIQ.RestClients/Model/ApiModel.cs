﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.RestClients.Model
{
    public abstract class ApiModel
    {
    }
}
