﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace DeliverIQ.RestClients.Model
{
    public abstract class ApiResponse<T> : ApiResponse
    {
        public T Data { get; set; }
    }
    public abstract class ApiResponse
    {
        public bool StatusIsSuccessful { get; set; }
        public ErrorStateResponse ErrorState { get; set; }
        public HttpStatusCode ResponseCode { get; set; }
        public string ResponseResult { get; set; }
    }
    public class ErrorStateResponse
    {
        public string Message { get; set; }
        public IDictionary<string, string[]> ModelState { get; set; }
    }
    public class BooleanResponse : ApiResponse<bool> { }

    public class DeletedResponse : ApiResponse { }

    public class StringResponse : ApiResponse<string> { }
}
