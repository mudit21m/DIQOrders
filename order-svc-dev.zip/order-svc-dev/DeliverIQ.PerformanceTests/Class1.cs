﻿using System;

namespace DeliverIQ.PerformanceTests
{
    public class Class1
    {
    }
}
