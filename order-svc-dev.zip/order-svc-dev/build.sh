#!/bin/bash -e
set -e
set -x #echo on


_AWSAccount=$(aws sts get-caller-identity --output text --query "Account" )
_ContainerReg="$_AWSAccount.dkr.ecr.$_Region.amazonaws.com"
_ECR="https://$_AWSAccount.dkr.ecr.$_Region.amazonaws.com"

docker build -t $_Image:v0.${BUILD_NUMBER} .
docker tag $_Image:v0.${BUILD_NUMBER} $_ContainerReg/$_Image$_BuildType:v0.0.${BUILD_NUMBER} 
docker tag $_Image:v0.${BUILD_NUMBER} $_ContainerReg/$_Image$_BuildType:latest

docker login -u AWS -p $(aws ecr get-login-password --region eu-west-1)  $_ECR
echo docker login -u AWS -p $(aws ecr get-login-password --region eu-west-1)  $_ECR

docker push $_ContainerReg/$_Image$_BuildType:v0.0.${BUILD_NUMBER}
docker push $_ContainerReg/$_Image$_BuildType:latest