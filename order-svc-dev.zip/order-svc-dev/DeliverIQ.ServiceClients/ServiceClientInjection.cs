﻿using Microsoft.Extensions.DependencyInjection;
using DeliverIQ.ServiceClients;
using DeliverIQ.ServiceClients.Implementation;
using DeliverIQ.ServiceClients.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using DeliverIQ.RestClients;

namespace DeliverIQ.ServiceClients
{
    public static class ServiceClientInjection
    {
        public static IServiceCollection RegisterServiceClient(this IServiceCollection services)
        {
            services.AddSingleton<ITNTServiceClient, TNTServiceClient>();
            services.AddSingleton<IDHLServiceClient, DHLServiceClient>();
            services.AddSingleton<IEtsyServiceClient, EtsyServiceClient>();
            services.AddSingleton<IVolusionServiceClient, VolusionServiceClient>();


            services.RegisterRestClient();
            return services;
        }
    }
}
