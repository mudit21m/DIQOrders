﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.ServiceClients
{
    public abstract class BaseServiceClient
    {
        protected const string Slash = "/";
        protected const string BaseApiUri = "api";
        protected const string LogOutUri = BaseApiUri + "/logout/";

        //protected readonly ClientBase _apiClientBase;
        //protected readonly FHttpClientFactory _httpClientFactory;
        //protected readonly ITokenContainer _tokenContainer;


        //public BaseServiceClient(ITokenContainer tokenContainer, FHttpClientFactory httpClientFactory)
        //{
        //    _tokenContainer = tokenContainer;
        //    _apiClientBase = new ClientBase(new ApiHelper.Client.ApiClient(_tokenContainer, httpClientFactory.Resolve()));
        //    _httpClientFactory = httpClientFactory;
        //}
    }
}
