﻿using DeliverIQ.RestClients.Model;
using DeliverIQ.ServiceClients.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.ServiceClients.Response
{
    public  class EtsyResponse : ApiResponse<EtsyOrderModel>
    {
    }
    public class ListOfEtsyOrderResponse : ApiResponse<List<EtsyOrderModel>>
    {
    }
}
