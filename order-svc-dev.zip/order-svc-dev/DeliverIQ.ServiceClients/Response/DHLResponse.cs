﻿using DeliverIQ.RestClients.Model;
using DeliverIQ.ServiceClients.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.ServiceClients.Response
{
    public  class DHLResponse : ApiResponse<DHLOrderModel>
    {
    }
    public class ListOfDHLOrderResponse : ApiResponse<List<DHLOrderModel>>
    {
    }
}
