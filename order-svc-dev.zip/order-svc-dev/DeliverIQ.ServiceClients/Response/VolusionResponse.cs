﻿using DeliverIQ.ServiceClients.Model;
using System;
using System.Collections.Generic;
using System.Text;
using DeliverIQ.RestClients.Model;

namespace DeliverIQ.ServiceClients.Response
{
    public  class VolusionResponse : ApiResponse<VolusionOrderModel>
    {
    }
    public class ListOfVolusionOrderResponse : ApiResponse<List<VolusionOrderModel>>
    {
    }
}
