﻿using DeliverIQ.RestClients.Model;
using DeliverIQ.ServiceClients.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.ServiceClients.Response
{
    public  class TNTResponse : ApiResponse<TNTOrderModel>
    {
    }
    public class ListOfTNTOrderResponse : ApiResponse<List<TNTOrderModel>>
    {
    }
}
