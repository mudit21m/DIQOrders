﻿using DeliverIQ.RestClients.Model;
using DeliverIQ.ServiceClients.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.ServiceClients.Model
{
    public class DHLOrderModel: ApiModel
    {
        public int ID { get; set; }
        public int OrderID { get; set; }
        public string UserID { get; set; }

    }
}
