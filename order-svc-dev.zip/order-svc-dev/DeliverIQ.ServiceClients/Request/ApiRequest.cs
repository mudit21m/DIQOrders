﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.ServiceClients.Request
{
    public abstract class ApiRequest<T> : ApiRequest
    {
        public T ParamData { get; set; }
    }
    public abstract class ApiRequest
    {
        public string SecretAccessKey { get; set; }
        public string AccessKey { get; set; }

    }
}
