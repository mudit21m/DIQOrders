﻿using DeliverIQ.ServiceClients.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.ServiceClients.Request
{
    public class VolusionRequest : ApiRequest<VolusionOrderModel>
    {
        public string AuthKey { get; set; }
    }



}
