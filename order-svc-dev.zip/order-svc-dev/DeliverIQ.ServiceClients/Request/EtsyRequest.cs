﻿using DeliverIQ.ServiceClients.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.ServiceClients.Request
{
    public class EtsyRequest : ApiRequest<EtsyOrderModel>
    {
        public string AuthKey { get; set; }
    }



}
