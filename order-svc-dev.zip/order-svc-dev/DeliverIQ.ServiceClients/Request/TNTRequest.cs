﻿using DeliverIQ.ServiceClients.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.ServiceClients.Request
{
    public class TNTRequest : ApiRequest<TNTOrderModel>
    {
        public string TNTCode { get; set; }
    }
}
