﻿using DeliverIQ.ServiceClients.Interface;
using DeliverIQ.ServiceClients.Model;
using DeliverIQ.ServiceClients.Request;
using DeliverIQ.ServiceClients.Response;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using DeliverIQ.RestClients.Implementation;

namespace DeliverIQ.ServiceClients.Implementation
{
    public class DHLServiceClient : IDHLServiceClient
    {
        protected readonly ClientBase _apiClientBase;
        public DHLServiceClient(IHttpClientFactory clientFactory)
        {
            var apiClient = new ApiClient(clientFactory.CreateClient("dhlapi"));
            _apiClientBase = new ClientBase(apiClient);
        }

        public async Task<ListOfDHLOrderResponse> GetOrders(DHLRequest dHLRequest)
        {
            string apiUri = "Orders/";
            return await _apiClientBase.GetJsonContent<ListOfDHLOrderResponse, List<DHLOrderModel>>(apiUri);

        }

        public async Task<DHLResponse> GetOrderByID(DHLRequest dHLRequest)
        {
            string apiUri = "Orders/?OrderID=" + dHLRequest.ParamData.ID + "&userId=" + dHLRequest.ParamData.UserID;
            var result = await _apiClientBase.GetJsonContent<DHLResponse, DHLOrderModel>(apiUri);
            return result;

        }
    }
}
