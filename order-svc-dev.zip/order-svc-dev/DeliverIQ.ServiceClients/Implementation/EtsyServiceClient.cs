﻿using DeliverIQ.ServiceClients.Interface;
using DeliverIQ.ServiceClients.Model;
using DeliverIQ.ServiceClients.Request;
using DeliverIQ.ServiceClients.Response;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using DeliverIQ.RestClients.Implementation;

namespace DeliverIQ.ServiceClients.Implementation
{
    public class EtsyServiceClient : IEtsyServiceClient
    {
        protected readonly ClientBase _apiClientBase;
        public EtsyServiceClient(IHttpClientFactory clientFactory)
        {
            var apiClient = new ApiClient(clientFactory.CreateClient("etsyapi"));
            _apiClientBase = new ClientBase(apiClient);
        }
        public async Task<ListOfEtsyOrderResponse> GetOrders(EtsyRequest etsyRequest)
        {
            string apiUri = "Orders/";
            
            //var postModel = new EtsyOrderModel();
            //await _apiClientBase.PostJsonContent<ListOfEtsyOrderResponse, List<EtsyOrderModel>, EtsyOrderModel>(apiUri, postModel);
            
            return await _apiClientBase.GetJsonContent<ListOfEtsyOrderResponse, List<EtsyOrderModel>>(apiUri);
            

        }
    }
}
