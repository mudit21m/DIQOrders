﻿using DeliverIQ.RestClients.Implementation;
using DeliverIQ.ServiceClients.Interface;
using DeliverIQ.ServiceClients.Model;
using DeliverIQ.ServiceClients.Request;
using DeliverIQ.ServiceClients.Response;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.ServiceClients.Implementation
{
    public class TNTServiceClient : ITNTServiceClient
    {
        protected readonly ClientBase _apiClientBase;
        public TNTServiceClient(IHttpClientFactory clientFactory)
        {
            var apiClient = new ApiClient(clientFactory.CreateClient("tntapi"));
            _apiClientBase = new ClientBase(apiClient);
        }

        public async Task<ListOfTNTOrderResponse> GetOrders(TNTRequest tNTRequest)
        {
            string apiUri = "Orders/";
            return await _apiClientBase.GetJsonContent<ListOfTNTOrderResponse, List<TNTOrderModel>>(apiUri);
        }

        public async Task<TNTResponse> GetOrderByID(TNTRequest tNTRequest)
        {
            string apiUri = "Orders/?OrderID=" + tNTRequest.ParamData.ID + "&userId=" + tNTRequest.ParamData.UserID;
            var result = await _apiClientBase.GetJsonContent<TNTResponse, TNTOrderModel>(apiUri);
            return result;

        }
    }
}
