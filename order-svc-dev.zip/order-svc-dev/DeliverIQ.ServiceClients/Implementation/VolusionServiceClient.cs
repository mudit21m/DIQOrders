﻿using DeliverIQ.RestClients.Implementation;
using DeliverIQ.ServiceClients.Interface;
using DeliverIQ.ServiceClients.Model;
using DeliverIQ.ServiceClients.Request;
using DeliverIQ.ServiceClients.Response;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.ServiceClients.Implementation
{
    public class VolusionServiceClient : IVolusionServiceClient
    {
        protected readonly ClientBase _apiClientBase;
        public VolusionServiceClient(IHttpClientFactory clientFactory)
        {
            var apiClient = new ApiClient(clientFactory.CreateClient("volusionapi"));
            _apiClientBase = new ClientBase(apiClient);
        }

        public async Task<ListOfVolusionOrderResponse> GetOrders(VolusionRequest volusionRequest)
        {
            Dictionary<string, string> headers = GetHeaders();

            string apiUri = "Orders/";
            return await _apiClientBase.GetJsonContent<ListOfVolusionOrderResponse, List<VolusionOrderModel>>(apiUri, headers);

        }

        private static Dictionary<string, string> GetHeaders()
        {
            Dictionary<string, string> headers = new Dictionary<string, string>();
            headers.Add("Accept", "application/vnd.github.v3+json");
            headers.Add("User-Agent", "HttpClientFactory-Sample");
            return headers;
        }
    }
}
