﻿using DeliverIQ.ServiceClients.Request;
using DeliverIQ.ServiceClients.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.ServiceClients.Interface
{
    public interface IVolusionServiceClient
    {
        Task<ListOfVolusionOrderResponse> GetOrders(VolusionRequest volusionRequest);
    }
}
