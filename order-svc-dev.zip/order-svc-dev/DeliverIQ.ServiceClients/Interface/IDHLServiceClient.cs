﻿using DeliverIQ.ServiceClients.Request;
using DeliverIQ.ServiceClients.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.ServiceClients.Interface
{
    public interface IDHLServiceClient
    {
        Task<ListOfDHLOrderResponse> GetOrders(DHLRequest dHLRequest);
        Task<DHLResponse> GetOrderByID(DHLRequest dHLRequest);
    }
}
