﻿using DeliverIQ.ServiceClients.Request;
using DeliverIQ.ServiceClients.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DeliverIQ.ServiceClients.Interface
{
    public interface ITNTServiceClient
    {
        Task<ListOfTNTOrderResponse> GetOrders(TNTRequest tNTRequest);
        Task<TNTResponse> GetOrderByID(TNTRequest tNTRequest);
    }
}
