﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model.Response
{
    public class OrderList
    {
        public long id { get; set; }
        public string diq_order_number { get; set; }
        public DateTime order_created_date { get; set; }

        public int marketplace_id { get; set; }

        public string marketplace_name { get; set; }
        public string marketplace_order_number { get; set; }
        public long order_status_id { get; set; }
        public decimal order_total { get; set; }
        public decimal order_subtotal { get; set; }
        public long user_id { get; set; }
        public string del_country_name { get; set; }
        public string del_city { get; set; }
        public string del_postal_code { get; set; }
        public long del_state_id { get; set; }
        public string name { get; set; }
        public string surname { get; set; }
        public string phone_no { get; set; }
        public string email_id { get; set; }
        public long order_product_id { get; set; }
        public long varient_id { get; set; }
        public long product_id { get; set; }
        public string variant_name { get; set; }
        public string product_name { get; set; }

        public string carrier { get; set; }
    }
}
