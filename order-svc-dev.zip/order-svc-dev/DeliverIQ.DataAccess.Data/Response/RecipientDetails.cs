﻿using DeliverIQ.Utilities;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Response
{
    public class RecipientDetails
    {
        public long user_id { get; set; }

        public string name { get; set; }
        public string surname { get; set; }

        public long title { get; set; }

        public string email_id { get; set; }

        public string phone_number { get; set; }

        public bool is_active { get; set; }

        public bool is_deleted { get; set; }


        public long recipient_id { get; set; }
        public AddressType address_type { get; set; }
        public long address_id { get; set; }

        public string delivery_address1 { get; set; }
        public string delivery_address2 { get; set; }
        public string delivery_address3 { get; set; }
        public string delivery_city { get; set; }
        public long delivery_state_id { get; set; }
        public string delivery_postal_code { get; set; }
        public long delivery_country_id { get; set; }
        public bool delivery_is_residential { get; set; }

        public string billing_address1 { get; set; }
        public string billing_address2 { get; set; }
        public string billing_address3 { get; set; }
        public string billing_city { get; set; }
        public long billing_state_id { get; set; }
        public string billing_postal_code { get; set; }
        public long billing_country_id { get; set; }
        public bool billing_is_residential { get; set; }
    }
}
