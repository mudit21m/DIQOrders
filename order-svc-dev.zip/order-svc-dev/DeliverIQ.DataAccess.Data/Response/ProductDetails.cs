﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Response
{
    public class ProductDetails
    {
        public long id { get; set; }
        public string barcode { get; set; }
        public long barcode_type_id { get; set; }
        public decimal base_price { get; set; }
        public long currency_id { get; set; }
        public string diq_product_code { get; set; }
        public bool has_variant { get; set; }
        public string product_description { get; set; }
        public long product_fiscal_group_id { get; set; }
        public string product_name { get; set; }
        public long product_status { get; set; }
        public long user_id { get; set; }
        public decimal product_tax { get; set; }

        public long image_id { get; set; }
        public string image_url { get; set; }
        public long image_variant_id { get; set; }
        public long image_product_id { get; set; }

        public long variant_id { get; set; }
        public string variant_additional_description { get; set; }
        public string variant_barcode { get; set; }
        public long variant_barcode_type_id { get; set; }
        public bool variant_is_seprate_barcode { get; set; }
        public string variant_name { get; set; }
        public long variant_product_id { get; set; }


        public long package_id { get; set; }
        public long package_variant_id { get; set; }
        public decimal package_width { get; set; }
        public decimal package_height { get; set; }
        public decimal package_length { get; set; }
        public decimal package_weight { get; set; }
        public long package_dim_unit { get; set; }
        public long package_weight_unit { get; set; }
    }
}
