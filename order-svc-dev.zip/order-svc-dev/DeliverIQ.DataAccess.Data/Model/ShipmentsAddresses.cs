﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class ShipmentsAddresses : BaseEntity
    {
        public long shipment_id { get; set; }
        public string origin_address_1 { get; set; }
        public string origin_address_2 { get; set; }
        public string origin_address_3 { get; set; }
        public string origin_postalcode { get; set; }
        public long origin_country_id { get; set; }
        public string origin_email { get; set; }
        public string origin_phone { get; set; }
        public string origin_city { get; set; }
        public string origin_state { get; set; }
        public string origin_company { get; set; }
        public string origin_contact { get; set; }
        public string origin_vat_no { get; set; }
        public string destination_address_1 { get; set; }
        public string destination_address_2 { get; set; }
        public string destination_address_3 { get; set; }
        public string destination_postalcode { get; set; }
        public long destination_country_id { get; set; }
        public string destination_email { get; set; }
        public string destination_phone { get; set; }
        public string destination_city { get; set; }
        public string destination_state { get; set; }
        public string destination_company { get; set; }
        public string destination_contact { get; set; }
        public string destination_vat_no { get; set; }
    }
}
