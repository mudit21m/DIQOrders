﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class ProductsPackages
    {
        public long id { get; set; }
        public long product_id { get; set; }
        public long variant_id { get; set; }
        public decimal width { get; set; }
        public decimal height { get; set; }
        public decimal length { get; set; }
        public decimal weight { get; set; }
        public long dim_unit { get; set; }
        public long weight_unit { get; set; }

    }
}
