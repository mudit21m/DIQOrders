﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class States
    {
        public int id { get; set; }
        public string name { get; set; }
        public string code { get; set; }
        public int country_id { get; set; }
    }
}
