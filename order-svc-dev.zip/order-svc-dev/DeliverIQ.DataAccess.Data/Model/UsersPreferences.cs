﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class UsersPreferences : BaseEntity
    {
        public long user_id { get; set; }
        public int code { get; set; }
        public string desciption { get; set; }
        public string value { get; set; }
    }
}
