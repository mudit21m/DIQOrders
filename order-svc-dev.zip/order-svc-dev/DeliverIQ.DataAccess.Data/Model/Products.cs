﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class Products : BaseEntity
    {

        public string product_name { get; set; }
        public long user_id { get; set; }
        public string diq_product_code { get; set; }
        public decimal base_price { get; set; }
        public long currency_id { get; set; }
        public string product_description { get; set; }
        public long product_fiscal_group_id { get; set; }
        public long barcode_type_id { get; set; }
        public string barcode { get; set; }
        public bool has_variant { get; set; }

        public long product_status { get; set; }

        public decimal product_tax { get; set; }
    }
}
