﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class Countries
    {
        public int id { get; set; }
        public string name { get; set; }
        public string code { get; set; }
        public string culture_code { get; set; }
        public int continent { get; set; }
        public string postalcode { get; set; }
        public string location { get; set; }
        public string statecode { get; set; }
        public string timezone { get; set; }
    }
}
