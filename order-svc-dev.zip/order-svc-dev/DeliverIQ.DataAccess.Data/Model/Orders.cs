﻿using DeliverIQ.Utilities;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class Orders : BaseEntity
    {
        public long? customer_marketplace_id { get; set; }
        public string diq_order_number { get; set; }
        public string marketplace_order_number { get; set; }
        public string marketplace_order_id { get; set; }
        public DateTime order_date { get; set; }
        public DateTime order_created_date { get; set; }
        public DateTime? order_modified_date { get; set; }
        public DateTime ship_by_date { get; set; }
        public OrderStatus order_status_id { get; set; }
        public decimal order_total { get; set; }
        public decimal shipping_amount { get; set; }
        public bool is_fulfilled { get; set; }
        public long order_modification_status { get; set; }
        public long? shipping_type_mode { get; set; }
        public string ship_transit_time { get; set; }
        public decimal order_subtotal { get; set; }
        public decimal? order_discount { get; set; }
        public string order_discount_type { get; set; }
        public decimal order_misc_charges { get; set; }
        public decimal order_tax { get; set; }
        public string order_carrier { get; set; }
        public string order_shipping_notes { get; set; }
        public PaymentTypes payment_type { get; set; }
        public long? user_id { get; set; }

        public bool? is_deleted { get; set; }
    }
}
