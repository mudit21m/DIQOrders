﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class BarcodeTypes : BaseEntity
    {
        public string name{ get; set; }
    }
}
