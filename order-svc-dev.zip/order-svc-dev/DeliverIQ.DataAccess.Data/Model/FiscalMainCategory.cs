﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class FiscalMainCategory
    {
        public int id { get; set; }
        public string name { get; set; }
        public int fiscal_group_id { get; set; }

    }
}
