﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class UsersAddresses
    {
        public long id { get; set; }
        public long user_id { get; set; }
        public int address_type { get; set; }
        public string address1 { get; set; }
        public string address2 { get; set; }
        public string address3 { get; set; }
        public string city { get; set; }
        public int? state_id { get; set; }
        public string postal_code { get; set; }
        public long country_id { get; set; }
        public string phone_number { get; set; }
        public string email { get; set; }
        public string mobile_number { get; set; }
        public bool is_active { get; set; }

    }
}
