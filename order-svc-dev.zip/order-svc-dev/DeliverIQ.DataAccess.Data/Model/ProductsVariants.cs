﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class ProductsVariants : BaseEntity
    {
        public long product_id { get; set; }
        public string variant_name { get; set; }
        public string additional_description { get; set; }
        public bool is_seprate_barcode { get; set; }
        public long barcode_type_id { get; set; }
        public string barcode { get; set; }

    }
}
