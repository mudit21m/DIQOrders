﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class UsersFiltersPreferences : BaseEntity
    {
        public long user_filter_id { get; set; }
        public string key { get; set; }
        public string value { get; set; }
        public string code { get; set; }
    }
}
