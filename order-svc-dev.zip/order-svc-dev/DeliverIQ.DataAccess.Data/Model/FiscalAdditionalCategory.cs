﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class FiscalAdditionalCategory
    {
        public int id { get; set; }
        public string name { get; set; }
        public int fiscal_main_category { get; set; }

    }
}
