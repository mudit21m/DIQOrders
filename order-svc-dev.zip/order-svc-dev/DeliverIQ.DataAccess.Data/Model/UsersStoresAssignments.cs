﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class UsersStoresAssignments
    {
        public int id { get; set; }
        public int user_id { get; set; }
        public int marketplace_id { get; set; }
    }
}
