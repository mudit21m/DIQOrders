﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class Users : BaseEntity
    {
        public string name { get; set; }
        public string phone_no { get; set; }
        public string country_name { get; set; }
        public bool address_verified { get; set; }
        public long account_status { get; set; }
        public long role_id { get; set; }
        public string email_id { get; set; }
        public string password { get; set; }
        public string diq_reference_number { get; set; }
        public long parent_id { get; set; }
        public bool is_active { get; set; }
    }
}
