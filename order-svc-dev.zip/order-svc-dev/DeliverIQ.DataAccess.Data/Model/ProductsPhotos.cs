﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class ProductsPhotos : BaseEntity
    {
        public long product_id { get; set; }
        public string image_url { get; set; }
        public long variant_id { get; set; }

    }
}
