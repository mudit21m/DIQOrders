﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class OrderDetails
    {
        public long id { get; set; }
        public string diq_order_number { get; set; }
        public DateTime order_date { get; set; }
        public DateTime order_created_date { get; set; }
        public DateTime ship_by_date { get; set; }
        public long order_status_id { get; set; }
        public decimal order_total { get; set; }
        public decimal shipping_amount { get; set; }
        public bool is_fulfilled { get; set; }
        public int order_modification_status { get; set; }
        public long? shipping_type_mode { get; set; }
        public string ship_transit_time { get; set; }
        public decimal order_subtotal { get; set; }
        public decimal order_discount { get; set; }
        public string order_discount_type { get; set; }
        public decimal order_tax { get; set; }
        public string order_shipping_notes { get; set; }
        public long payment_type { get; set; }
        public long user_id { get; set; }
        public int bill_order_address_type { get; set; }
        public long bill_country_id { get; set; }
        public string bill_address_line_1 { get; set; }
        public string bill_address_line_2 { get; set; }
        public string bill_address_line_3 { get; set; }
        public string bill_city { get; set; }
        public string bill_postal_code { get; set; }
        public bool bill_is_residential { get; set; }
        public long bill_state_id { get; set; }
        public long bill_id { get; set; }
        public int title { get; set; }
        public string name { get; set; }
        public string surname { get; set; }
        public string phone_no { get; set; }
        public string email_id { get; set; }
        public int del_order_address_type { get; set; }
        public long del_country_id { get; set; }
        public string del_address_line_1 { get; set; }
        public string del_address_line_2 { get; set; }
        public string del_address_line_3 { get; set; }
        public string del_city { get; set; }
        public string del_postal_code { get; set; }
        public bool del_is_residential { get; set; }
        public long del_state_id { get; set; }
        public long del_id { get; set; }
        public long order_product_id { get; set; }
        public long varient_id { get; set; }
        public long product_id { get; set; }
        public long quantity { get; set; }
        public string variant_name { get; set; }
        public string product_name { get; set; }
        public decimal unit_price { get; set; }
        public int shipment_id { get; set; }
    }
}
