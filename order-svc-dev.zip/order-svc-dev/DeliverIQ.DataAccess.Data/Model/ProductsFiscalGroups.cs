﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class ProductsFiscalGroups : BaseEntity
    {
        public long user_id { get; set; }
        public string name { get; set; }

    }
}
