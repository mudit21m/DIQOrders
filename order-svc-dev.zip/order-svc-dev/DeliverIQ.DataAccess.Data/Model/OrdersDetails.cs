﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class OrdersDetails : BaseEntity
    {
        public decimal weight { get; set; }
        public int weight_unit { get; set; }
        public decimal length { get; set; }
        public decimal width { get; set; }
        public decimal height { get; set; }
        public long dimension_unit { get; set; }
        public int total_quantity { get; set; }
        public decimal total_amount { get; set; }
       
    }
}
