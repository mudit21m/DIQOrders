﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class UsersMarketplaces : BaseEntity
    {
        public long marketplace_id { get; set; }
        public long user_id { get; set; }
        public string store_name { get; set; }
        public long refresh_rate { get; set; }
        public bool is_auto_refresh { get; set; }

        public DateTime last_refresh_attempt { get; set; }
        public bool is_active { get; set; }
    }
}
