﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class OrdersProducts : BaseEntity
    {
        public long order_id { get; set; }
        public long product_id { get; set; }
        public string variant_name { get; set; }
        public string product_name { get; set; }
        public long varient_id { get; set; }
        public decimal unit_price { get; set; }
        public long quantity { get; set; }
        public bool is_active { get; set; }
        public long shipment_id { get; set; }

        public bool? is_deleted { get; set; }
    }
}
