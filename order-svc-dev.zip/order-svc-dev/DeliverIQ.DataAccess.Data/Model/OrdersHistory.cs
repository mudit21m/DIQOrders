﻿using DeliverIQ.Utilities;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class OrdersHistory : BaseEntity
    {
        public long order_id { get; set; }
        public int order_status { get; set; }
        public decimal order_total { get; set; }
        public int user_id{ get; set; }
        public decimal shipping_amount { get; set; }
        public string order_shipping_notes{ get; set; }
        public DateTime order_modified_date_source{ get; set; }
    }
}
