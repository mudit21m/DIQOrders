﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public abstract class BaseEntity
    {
        public long id { get; set; }
        public long created_by { get; set; }
        public long? updated_by { get; set; }
        public DateTime created_on { get; set; }
        public DateTime? updated_on { get; set; }
    }
}
