﻿using DeliverIQ.Utilities;
using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class OrdersAddresses : BaseEntity
    {
        public AddressType order_address_type { get; set; }
        public string name { get; set; }
        public string surname { get; set; }
        public string email_id { get; set; }
        public long title { get; set; }
        public string company { get; set; }
        public string address_line_1 { get; set; }
        public string address_line_2 { get; set; }
        public string address_line_3 { get; set; }
        public string city { get; set; }
        public long state_id { get; set; }
        public string postal_code { get; set; }
        public string phone_no { get; set; }
        public long country_id { get; set; }
        public long order_id { get; set; }
        public bool is_residential { get; set; }
    }
}
