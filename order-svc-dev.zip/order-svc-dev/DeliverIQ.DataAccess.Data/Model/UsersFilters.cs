﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class UsersFilters : BaseEntity
    {
        public long user_id { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public bool is_filter_for_user { get; set; }
        public int screen_type { get; set; }
    }
}
