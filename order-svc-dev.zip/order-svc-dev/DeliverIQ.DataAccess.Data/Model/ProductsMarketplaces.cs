﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class ProductsMarketplaces
    {
        public long id { get; set; }
        public long product_id { get; set; }
        public long marketplace_id { get; set; }
    }
}
