﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class ShipmentsCharges : BaseEntity
    {
        public long shipment_id { get; set; }
        public long charge_type_master_id { get; set; }
        public decimal diq_cost { get; set; }
        public decimal customer_cost { get; set; }
    }
}
