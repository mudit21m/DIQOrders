﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class MarketplacesConfigurations : BaseEntity
    {
        public int user_marketplace_id { get; set; }
        public string access_token { get; set; }
        public string access_secret { get; set; }
        public string client_key { get; set; }
        public string client_secret { get; set; }
        public string store_url { get; set; }
        public int user_id { get; set; }
        public string user_name { get; set; }
        public string region_name { get; set; }
        public bool is_active { get; set; }
    }
}
