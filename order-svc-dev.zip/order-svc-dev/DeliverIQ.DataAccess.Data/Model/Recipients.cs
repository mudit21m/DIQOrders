﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class Recipients : BaseEntity
    {
        public long user_id { get; set; }

        public string name { get; set; }
        public string surname { get; set; }

        public long title { get; set; }

        public string email_id { get; set; }

        public string phone_number { get; set; }

        public bool is_active { get; set; }

        public bool is_deleted { get; set; }
    }
}
