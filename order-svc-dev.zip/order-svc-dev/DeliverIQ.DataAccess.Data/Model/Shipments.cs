﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeliverIQ.DataAccess.Data.Model
{
    public class Shipments : BaseEntity
    {
        public long shipment_address { get; set; }
        public string carrier_tracking_no { get; set; }
        public string tracking_no { get; set; }
        public string insurance { get; set; }
        public int status { get; set; }
        public long carrier_id { get; set; }
        public DateTime booked_date { get; set; }
        public int pieces { get; set; }
        public string collection_on { get; set; }
        public string collection_reference_no { get; set; }
        public decimal shipment_base { get; set; }
        public decimal shipment_vat { get; set; }
        public decimal shipment_gross { get; set; }
        public decimal shipment_fuel { get; set; }
        public int payment_mode { get; set; }
        public string diq_ref { get; set; }
        public string shipment_reference { get; set; }
        public bool is_shipment_delivered { get; set; }
        public bool is_voided { get; set; }
        public long user_id { get; set; }
        public long service_id { get; set; }
        public long package_id { get; set; }
    }
}
