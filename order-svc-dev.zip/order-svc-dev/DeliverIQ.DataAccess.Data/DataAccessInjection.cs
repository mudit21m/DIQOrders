﻿using System;
using System.Collections.Generic;
using System.Text;
using DeliverIQ.DataAccess.Data;
using Microsoft.Extensions.DependencyInjection;

namespace DeliverIQ.DataAccess.Data
{
    public static class DataAccessInjection
    {
        public static IServiceCollection RegisterDataAccess(this IServiceCollection services)
        {
            return services;
        }
    }
}
