﻿using DeliverIQ.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Globalization;

namespace DeliverIQ.DataAccess.Data.Model.Request
{
    public partial class OrderFilter
    {

        public FilterSort Order { get; set; }

        public FilterSort Channel { get; set; }

        public FilterSort CreatedDate { get; set; }

        public FilterSort Customer { get; set; }

        public FilterSort Country { get; set; }

        public FilterSort Postcode { get; set; }

        public FilterSort SourceId { get; set; }

        public FilterSort Amount { get; set; }

        public FilterSort Status { get; set; }

        public Pagging Pagging { get; set; }

        public AdvanceFilter AdvanceFilter { get; set; }
    }

    public partial class FilterSort
    {
        public string Sort { get; set; }

        public List<string> Filter { get; set; }
    }

    public partial class Pagging
    {
        public int PageNo { get; set; }
        public int PageSize { get; set; }

    }

    public partial class AdvanceFilter
    {
        public AdvanceFilter()
        {
            IsAdavanceFilterApply = false;
        }
        public bool IsAdavanceFilterApply { get; set; }
        public SearchOption SourceOrderNumber { get; set; }

        public SearchOption DeliveryIQOrderNumber { get; set; }

        public SearchOption CustomerReference { get; set; }

        public SearchOption Source { get; set; }

        public SearchOption CarrierTrackingReference { get; set; }

        public SearchOption Surname { get; set; }

        public SearchOption DeliveryPostcode { get; set; }

        public SearchOption EmailAddress { get; set; }

        public SearchOption TelephoneNumber { get; set; }

        public SearchOption ProductDescription { get; set; }
    }

    public partial class SearchOption
    {
        public string Filter { get; set; }
    }
}
