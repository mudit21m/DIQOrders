﻿using System;

namespace DeliverIQ.UnitTests
{
    public class Class1
    {
    }
}
