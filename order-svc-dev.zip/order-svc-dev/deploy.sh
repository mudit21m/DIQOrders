#!/bin/bash -e
set -e
set -x #echo on

_Image="dev-diq-ecr/order-svc"
_PreFixEnv="dev-"
_DeploymentImage="order-svc"
_Region="eu-west-1"
_AWSAccount=$(aws sts get-caller-identity --output text --query "Account" )
_ContainerReg="$_AWSAccount.dkr.ecr.$_Region.amazonaws.com"
_ECR="https://$_AWSAccount.dkr.ecr.$_Region.amazonaws.com"


kubectl scale deployments/$_DeploymentImage-deployment  --replicas 1
kubectl apply -f $_PreFixEnv$_DeploymentImage.yaml
kubectl set image deployments/$_DeploymentImage-deployment $_DeploymentImage-deployment=$_ContainerReg/$_Image$_BuildType:v0.0.${BUILD_NUMBER}
kubectl rollout status deployments $_DeploymentImage-deployment

